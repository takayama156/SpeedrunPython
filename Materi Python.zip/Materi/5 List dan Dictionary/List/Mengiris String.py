kalimat = "Saya suka Python"

saya = kalimat[:4]

suka = kalimat[5:9]

python = kalimat[10:]

print("saya : '{}'".format(saya))
print("suka : '{}'".format(suka))
print("python : '{}'".format(python))

'''Anda bisa mengiris string selayaknya anda mengiris lists. Bahkan kita bisa berpikir bahwa string adalah sebuah kumpulan karakter di list! Caranya mengiris string sama seperti kita mengiris lists:

makanan = "Lontong Sayur"
print makanan[0:7] # Lontong
print makanan[8:13] # Sayur
Dengan contoh di atas, kebayangkan cara kerjanya mengiris string? Kalo bingung coba-coba aja di samping dan jalankan.

Untuk mempermudah penulisan, jika mengiris dari awal, kita tidak perlu menuliskan indeks 0nya, atau di contoh atas menjadi makanan[:7]. Dan juga jika kita mengiris hingga akhir, kita bisa mengabaikan indeks akhirnya menjadi seperti ini makanan[8:]. Simpel kan?'''

'''Kita mempunyai kalimat di samping yang merupakan sebuah string.
Silahkan iris "suka" dari kalimat dan masukkan ke variabel suka.
Sekali lagi lakukan hal yang sama dengan "python".
Perhatikan spasinya saat mengiris, jangan sertakan spasi di suka maupun python.
Variabel saya telah kita selesaikan sebagai contoh.'''

'''Perhatikan outputnya, ubah indeksnya untuk 'menyetel' keluarannya.'''