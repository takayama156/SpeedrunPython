makanan = ["lontong sayur", "bakso", "somay", "bajigur"]

makanan[2] = "sate"
makanan.append("batagor")
makanan.append("seblak")

print(makanan)

'''Sebuah list tidaklah harus memiliki panjang yang tetap. Kamu bisa menambahkan sebuah item di belakang list seperti ini:

primer = [ 2, 3, 5, 7, 11 ]
primer.append(13)
primer.append(17)
print len(primer)
print primer[5]
print primer[6]
Di code di atas, kita menambahkan elemen ke 6 dan ke 7 di primer. Untuk menambahkannya, kita cukup menggunakan keyword append. Untuk memastikan kalo operasi penambahan berhasil, kita bisa melihat bahwa panjang dari primer menjadi 7 dan kita bisa mencetak indeks ke 5 dan 6 di primer.'''

'''Instruksi:
Mari kita tambah daftar makanan yang kita punya!
Tambahkan 2 lagi item ke makanan dengan keyword append.'''