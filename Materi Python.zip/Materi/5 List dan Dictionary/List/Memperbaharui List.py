makanan = ["lontong sayur", "bakso", "somay", "bajigur"]

makanan[2] = "sate"

print(makanan)

'''Sebuah lists berperilaku layaknya sebuah variabel. Kita bisa mengaksesnya maupun memberikan nilai yang baru.

Kita telah belajar bagaimana caranya mengaksesnya di 2 unit sebelumnya:

print makanan[1] # 'bakso'
Kita pun bisa memberikan nilai baru di list dengan cara berikut:

makanan[1] = "es krim"'''

'''Di code samping kita telah memiliki variabel makanan yang mempunyai 4 item. Mendadak abang somay langganan anda banting setir dan memutuskan untuk jualan "sate". Kita pun harus mengubah data makanan kita. Tugas untuk anda, ubah data "somay" di makanan dengan "sate" karena abang sate langganan kita belum belajar Python.'''