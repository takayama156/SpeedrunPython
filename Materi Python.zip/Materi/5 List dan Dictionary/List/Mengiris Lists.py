benda = [ "oli", "kopi", "susu", "teh", "balsem" ]

minuman = benda[1:4]

print("saya minum " + str(minuman))

'''Selain menambahkan kita pun bisa mengiris lists, caranya seperti ini:

primer = [ 2, 3, 5, 7, 11, 13 ]
irisan = primer[2:4]
print primer
print irisan
Jalankan code di atas, dan anda akan lihat bahwa irisan adalah sebuah irisan dari primer. List irisan akan memiliki item ke 3 hingga ke 4 dari primer. Sehingga bisa kita simpulkan saat menuliskan primer[2:4] sebenernya kita berkata "Oke Python, iris variabel primer dimulai dari indeks ke 2 hingga di bawah indeks ke 4.". Perhatikan kata di bawah indeks ke 4. Maka karena itu elemen ke 5 dari primer tidak tersimpan di irisan.

Perhatikan juga bahwa mengiris menggunakan [] tidak akan mengubah list primer yang aslinya kecuali jika kita melakukan primer = primer[2:4].

Sekali lagi ingat ya, indeks itu angkanya selalu dimulai dari angka 0. Sementara hitungan urutan kita (baca: manusia) tetap dimulai dari angka 1.'''

'''Kita sudah punya variabel benda di samping.
Simpan di minuman yang merupakan irisan dari benda. Tapi ingat buat hanya yang benar-benar minuman yang disimpan di minuman.'''