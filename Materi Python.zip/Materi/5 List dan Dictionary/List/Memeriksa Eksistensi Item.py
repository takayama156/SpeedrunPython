makanan = ["lontong sayur", "sate", "somay", "karedok"]

if "nasi goreng" not in makanan:
  makanan.append("nasi goreng")

print(makanan)

'''Sering sekali kita ingin memeriksa apakah suatu item di list ada atau tidak. Caranya mudah saja di Python yaitu seperti ini:

minuman = [ "kopi", "susu", "teh"]
print 'bandrek' in minuman # False
print 'susu' in minuman # True
Dengan menggunakan in kita bisa memeriksa apakah 'bandrek' atau 'susu' ada di minuman atau tidak. Output dari operasi ini adalah boolean. Sehingga kita bisa mengkombinasikannya dengan if seperti berikut:

if 'bandrek' not in minuman:
  minuman.append('bandrek')
Perhatikan kita menggunakan not sebelum in sehingga "bandrek" not in minuman akan bernilai True jika "bandrek" tidak ada di minuman. Lalu jika tidak ada, maka kita bisa dengan mudah menambahkan sebuah item di minuman dengan append().

kata kunci in juga bisa gunakan di operasi string. Seperti ini:

print "suka" in "Saya suka Python"
yang akan mengeluarkan True.'''

'''Periksa jika "nasi goreng" ada di makanan atau tidak dengan not in.
Jika tidak ada, maka tambahkan "nasi goreng" ke makanan.'''