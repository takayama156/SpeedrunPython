makanan = ["lontong sayur","bakwan" , "bakso", ]

if len(makanan) > 2:
  print("Makanan kesukaan saya adalah {}".format( makanan[0] ))
  print("Makanan kesukaan saya adalah {}".format( makanan[1] ))
  print("Makanan kesukaan saya adalah {}".format( makanan[2] ))
  
'''Lists adalah sebuah tipe data yang bisa anda gunakan untuk menyimpan sebuah koleksi data di bawah sebuah variabel. Membuatnya cukup dengan menggunakan sintaks [] dan menggunakan , untuk memisahkan data yang satu dengan data yang lain. Contohnya seperti ini:

bunga = ["melati", "mawar", "patma"]
Di atas kita memiliki sebuah variabel bernama bunga yang merupakan sebuah lists. Lists ini memiliki tiga data yang kebetulan kesemuanya adalah string. Anda bisa menggabungkan tipe datanya seperti ini:

acak = [ "string", 1, 1.23 ]'''

'''Kita sudah membuat list yang bernama makanan yang baru memiliki 2 data. Tambahkan data ketiga di makanan. Tulis saja makanan kesukaan anda.'''