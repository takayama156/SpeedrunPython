kelas = [ "Python", "PHP", "JS"]

# mengakses indeks
print(kelas[0])

# mengupdate suatu item
kelas[2] = "JavaScript"

# menambahkan item
kelas.append("Git")

# mengiris item
server_side = kelas[:2]

# memeriksa item di list
print("Python" in kelas)

# dan menggunakan for
for k in kelas:
  print(k)
  
'''Kami berterimakasih anda terus belajar di CodeSaya. Sebagai tanda terimakasih, tidak ada tugas kali ini. Cukup lihat saja code di samping sehingga anda bisa mengulas sendiri apa yang telah anda pelajari. Dan jalankan!'''