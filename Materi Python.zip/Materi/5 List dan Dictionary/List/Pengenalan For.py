minuman = [ "kopi", "susu", "teh", "bandrek", "madu"]

for minum in minuman :
  print("Saya minum {}".format(minum))
  
'''Jika anda ingin melakukan sesuatu di setiap item di dalam list, kita bisa menggunakan for. Menggunakan for sangat mudah, cukup seperti ini:

for item in nama_list:
  # lakukan sesuatu, misalnya
  print item
Dengan code di atas, kita bisa mengiterasi semua item di nama_list dan mencetaknya. Nama variabel item dapat anda ubah menjadi apapun, yang penting belum digunakan sebelumnya agar tidak tumpang tindih. Perhatikan juga penggunaan titik dua : di akhir baris for. Dengan contoh sebelumnya kita bisa buat misalnya:

primer = [ 2, 3, 5 ]
for angka in primer:
  print angka * 2
yang akan mencetak:

4
6
10'''

'''Kita punya minuman di samping yang merupakan sebuah lists.
Mari gunakan for untuk mencetak setiap item di minuman ditambah dengan string "Saya minum ".'''