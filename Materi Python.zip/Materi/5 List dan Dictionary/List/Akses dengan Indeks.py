primer = [ 2, 3, 5, 7, 11 ]

print("Menambahkan primer di indeks ke 1 dan 3...")
print(primer[0] + primer[2])

print("Menambahkan primer di indeks ke 2 dan 5...")
print(primer[1] + primer[4])

'''Anda bisa mengakses sebuah data (atau item) di lists dengan nomor indeksnya. Sebuah indeks seperti sebuah alamat yang mengidentifikasi tempat sebuah data di list. Sintaksnya seperti ini: nama_list[indeks].

Seperti segala hal di dunia komputer, perhitungan indeks dimulai dari 0.'''

'''Perhatikan code di samping, instruksi anda ada di baris ke 6. Contoh mengerjakannya ada di baris ke 3 dan 4. Selamat mengerjakan!'''