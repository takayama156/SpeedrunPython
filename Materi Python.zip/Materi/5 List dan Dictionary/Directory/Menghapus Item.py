orang = { 'nama' : 'Linus Torvalds',
  'tahun lahir': 1969,
  'warga negara': 'Finlandia',
  'browser': 'nonIE' }

print(len(orang))

del orang['browser']

print(len(orang))

'''Setelah tahu cara untuk menambah, mari kita belajar caranya untuk menghapus. Yaitu dengan del seperti ini:

d = { 'key1': 'n1', 'key2': 'n2' }
del d['key1']
Di code atas, nantinya 'key1' akan hilang dari dictionary d.'''

'''Sederhana saja, cukup hapus kunci 'browser' di orang di baris ke 8.'''