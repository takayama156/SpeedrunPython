mobil_1 = { "warna" : "merah", "jumlah pintu": 4 }
mobil_2 = { "warna" : "putih", "jumlah pintu": 2 }

daftar_mobil = [mobil_1, mobil_2]

coder = { 'nama' : 'anda',
  'jomblo' : True }

coder['mobil'] = daftar_mobil
del coder['jomblo']

print(coder)

'''Anda tidak salah baca judul unit, memang benar kita bisa menggabungkan list dan dict. Dalam praktek coding sehari-hari itu sangat umum sekali untuk dilakukan. Sintaksnya mudah untuk ditebak, seperti ini contohnya:

org1 = {'nama': 'Abdul Muis', 'lahir':1883}
org2 = {'nama': 'Agus Salim', 'lahir':1884}
daftar_pahlawan = [org1, org2]
Di contoh atas kita membuat sebuah list bernama daftar_pahlawan yang isinya adalah org1 dan org2 yang masing-masing merupakan dictionary. Nantinya anda bisa menggunakannya sebagai berikut:

for p in daftar_pahlawan:
  print p['nama'] + " lahir tahun " + str(p['lahir'])
Dan juga sebaliknya kita bisa memasukkan dictionary ke dalam list. Seperti ini contohnya:

saya = {'nama':'saya', 
  'mantan' : ["Dian Sastro", "Raisa", "Agnes"] }
Seperti itu kira-kira. List nya bisa anda masukkan langsung ke saya seperti contoh di atas atau disimpan dulu di variabel. Nantinya bisa digunakan seperti ini:

for m in saya['mantan']:
  print m'''
  
''' Instruksi:
Unit ini adalah unit kesimpulan. Kaget kan? Hahaha... Ok mungkin tidak.

Anyway, semua yang anda pelajari di sub-bab ini akan ditanyakan di unit ini. Silahkan liat code di samping. Ikuti instruksi di komentar sebaik mungkin.'''