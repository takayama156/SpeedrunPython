orang = { 'nama' : 'Linus Torvalds',
  'tahun lahir': 1969,
  'warga negara': 'Finlandia',
  'browser': 'IE' }

orang={'os': 'linux', 'tempat tinggal': 'Amerika'}
orang['browser'] = 'nonIE'

print(orang['os'])
print(orang['tempat tinggal'])
print(orang['browser'])

'''Di dictionary kita bisa menambah item seperti ini:

d = { 'key1': 'n1', 'key2': 'n2' }
d['kunci baru'] = 'nilai baru'
Sederhana bukan? Dengan cara yang sama, kita pun bisa memperbarui nilai suatu kunci yang sudah ada seperti ini:

d['key1'] = 'nilai pengganti n1'
Di dictionary kita pun bisa menggunakan len() untuk menghitung seberapa banyak pasangan kunci dan nilai di sebuah dictionary seperti ini:

print len(d) # mencetak 3'''

'''Di samping kita masih punya dictionary bernama orang, mulai dari baris ke 6 lakukanlah hal ini:

Tambahkan sebuah kunci baru bernama 'os' yang diberikan nilai 'linux'.
Tambahkan lagi kunci baru bernama 'tempat tinggal' yang diberikan nilai 'Amerika'.
Woops, Linus menggunakan IE? Sudah pasti tidak. Kita harus menggantinya menjadi "nonIE" ^_^'''