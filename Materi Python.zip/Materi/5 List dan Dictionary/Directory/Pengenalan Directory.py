orang = { 'nama' : 'Linus Torvalds',
  'tahun lahir': 1969,
  'warga negara': 'Finlandia' }

print(orang['nama'])
print(orang['warga negara'])

'''Sebuah dictionary mirip seperti sebuah list, hanya saja kita mengaksesnya bukan dengan indeks tetapi dengan kunci (key). Sebuah kunci bisa merupakan angka atau string. Sintaksnya seperti ini:

d = { 'key1': 'n1', 'key2': 'n2' }
Sebuah dictionary dibuat dengan kurung kurawal {} berbeda dengan list yang dimulai dengan kurung kotak [].

Di contoh atas, kita memiliki sebuah dictionary bernama d yang memiliki 2 item. Kunci 'key1' di d mengarah ke 'n1', sementara itu kunci 'key2' mengarah ke 'n2'. Nilainya tidak harus string, tetapi juga bisa tipe data lain dan boleh dicampur-campur. Dan juga kita bisa membuat kuncinya berupa angka acak atau campur dengan string seperti ini:

org_dict = { 3 : "hi", "umur": 17, "coder": True }
Tipe data dictionary sangat bagus untuk menyimpan data dimana kita mengakses datanya secara acak. Sebagai contoh jika kita menggunakan list untuk contoh di atas:

org_list = [ "hi", 17, True ]
Di saat kita ingin mencetak umur mana yang lebih mudah?

print org_dict['umur']
print org_list[1]
Dengan menggunakan list, kita harus mengingat urutannya dan juga jika kita mengubah urutan dari org_dict, maka urutannya pun berubah! Selain itu membacanya pun lebih enak jika kita menggunakan dictionary. List digunakan untuk data dimana anda mengakses datanya secara berurutan.'''

'''Cetak 'nama' dan 'warga negara' dari dictionary orang.

Untuk mengakses dictionary, sintaksnya seperti ini:

nama_dict[kuncinya]'''