laptop = { 'warna' : 'perak',
  'processor' : 'i7',
  'merek' : 'apple', 
  'layar' : '4k',
  'harga' : 'Ro 69.000', }

if 'harga' in laptop:
  print(laptop['harga'])
else:
  print('ngak ada')
  
'''Apakah anda ingat bagaimana caranya memeriksa suatu indeks di lists? Yup, di dictionary caranya pun sama untuk memeriksa kunci, seperti ini:

print 'nama' in orang
print 'jumlah ban' in orang
Dengan menggunakan contoh dari unit sebelumnya, baris pertama di code atas akan menghasilkan True, dan baris ke dua akan menghasilkan False karena ini orang bukan mobil ^^.

Ini sangat penting sekali, karena jika anda tanpa tendeng aling-aling langsung print orang['jumlah ban'] maka Python akan menghasilkan error. Sebaiknya eksistensi dari kunci diperiksa dahulu seperti ini:

if 'jumlah ban' in orang:
  print orang['jumlah ban']
else:
  print 'jumlah ban tidak ada'''
  

'''Supaya tidak bosan, mari kita ganti orang dari unit sebelumnya dengan laptop. 

Di baris akhir code di samping, kita mencetak laptop['harga'] tanpa memeriksa apakah 'harga' sudah ada di laptop atau belum. Gunakan if dan in di baris sebelum print untuk memeriksa 'harga' ada di laptop atau tidak. Jangan lupakan untuk memberi spasi di sebelum print karena sekarang print masuk ke dalam if.'''