nama_pahlawan = ('Mohammad Yasin', 'I Gusti Ngurah Made Agung', 
  'Jamin Ginting', 'Lambertus Nicodemus Palar', 'Idham Chalid', 'Mas Isman')
for i in nama_pahlawan:
   print(i)

'''Tuple adalah suatu tipe data yang mirip dengan list dengan sebuah perbedaan besar yaitu tuple tidak bisa diubah baik dari ukuran maupun isinya. Jika list dibuat dengan [], dictionary dibuat dengan {}, maka tuple dibuat dengan (). Sebenarnya bisa juga dibuat dengan tidak menggunakan (), tetapi sebaiknya gunakan () agar mudah dibaca. Contoh tuple seperti ini:

tup = (0, 1, 2)

# bisa diakses seperti list
print tup[0]

# tetapi tidak bisa diubah
# code di bawah akan error
tup[0] = 9
Semua hal yang telah anda pelajari tentang list seperti for dapat diaplikasikan ke tuple. Masih ingat cara menggunakan for di list? Bagus sekarang anda akan mengaplikasikannya di unit ini tetapi untuk sebuah tuple. Anda pun bisa membuat sebuah variabel dengan tuple seperti ini:

x, y, z = (1, 2, 3)
print x # bernilai 1
print y # bernilai 2
print z # bernilai 3'''

'''Kita punya nama_pahlawan di samping dalam bentuk tuple. Cetak semuanya menggunakan for.'''

'''Nantinya jawaban anda akan mirip dengan ini:

for item in tuples:
  print item'''