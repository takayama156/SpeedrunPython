orang = { 'nama' : 'Guido van Rossum', 
  'umur' : 60,
  'kewarganegaraan': 'Belanda',
  'tempat tinggal': 'Amerika' }

for o in orang:
  print("{}: {}".format(o, orang[o]))
  
'''Salah satu kegunaan tuple adalah saat kita menggunakan items() di dictionary. Karena items() mengembalikan sebuah list yang masing-masing itemnya adalah tuple dan setiap tuplenya adalah pasangan kunci dan isi dari dictionary tersebut. Contohnya:

dic = { 'nama': 'saya',
  'umur' : 'uzur' }

print dic.items()
yang akan mengeluarkan [ ('nama', 'saya') , ('umur', 'uzur') ] , dan jika kita lihat indeks pertamanya:

print dic.items()[0]
akan mengeluarkan ('nama', 'saya') yang mana adalah sebuah tuple. Umumnya ini dipakai di for seperti ini:

for kunci, item in dic.items():
  print "{}: {}".format(kunci, item)'''
  
'''Cetak variabel orang di samping dengan format seperti contoh di tutorial di atas.'''