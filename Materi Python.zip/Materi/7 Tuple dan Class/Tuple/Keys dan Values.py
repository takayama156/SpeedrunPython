orang = { 'nama' : 'Guido van Rossum', 
  'umur' : 60,
  'kewarganegaraan': 'Belanda',
  'tempat tinggal': 'Amerika' }

for key in orang.keys():
  print(key)
for values in orang.values():
  print(values)
  
print("{} : {}".format(key, values))

'''Selain items(), kita juga punya keys() dan values() di dictionary. Keduanya akan mengeluarkan sebuah list dari kunci dan nilai di dictionary. Cara menggunakannya bisa dilihat di samping.'''

'''Jalankan code di samping. Anda akan melihat bahwa baik keys() dan values() menghasilkan sebuah list. Anda sudah tahu apa yang for bisa lakukan ke list. Gunakan for untuk mengiterasi setiap item hasil dari keys() atau values()'''