kubik_gasal = [a**3 for a in range (1, 21) if a % 2 == 1]

print(kubik_gasal)

'''Kita sudah tahu bagaimana memunculkan 10 angka kuadrat pertama. Tapi bagaimana jika dari 10 itu kita hanya ingin untuk memunculkan yang genap saja? Kita gunakan if:

[a**2 for a in range (1, 11) if a % 2 == 0]
untuk bagian a**2 for a in range (1, 11) kita sudah belajar di unit sebelumnya. Untuk bagian selanjutnya kita hanya bilang lakukan itu semua selama nilai modulus a terhadap 2 adalah 0. Jika anda lupa tentang modulus silahkan lihat-lihat lagi tentang modulus di sini. Selayaknya if, kita bisa buat banyak kondisi di dalamnya menjadi contohnya seperti berikut:

[a**2 for a in range (1, 11) if a % 2 == 1 and a % 5 != 0]'''

'''Mari kita buat sebuah list yang merupakan 20 angka pangkat tiga pertama menggunakan range(). Tapi hanya yang gasal (atau ganjil) saja. Lalu simpan angka tersebut di sebuah variabel bernama kubik_gasal'''