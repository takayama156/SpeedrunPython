kubik = [a**3 for a in range(1, 11)]

print(kubik)

'''Anda sudah tahu bahwa range() dapat membuat list. Untuk membuat list dari angka 0 hingga ke 100 kita cukup menggunakan range(101). Sedangkan untuk membuat list dari angka 0 ke 100 untuk setiap angka genap kita menggunakan range(0, 101, 2). Tapi bagaimana jika anda ingin membuat 5 angka kuadrat yang pertama? Dengan range kita bisa melakukannya dengan mudah. Seperti ini:

[a**2 for a in range (1, 6)]
menghasilkan [1, 4, 9, 16, 25]. Cara membaca code di atas adalah: pangkat 2-kan a ketika a adalah angka dari 1 hingga 6 lalu (dengan []) kita jadikan sebuah list.'''

'''Sekarang buatlah sebuah list yang merupakan 10 angka pangkat tiga pertama menggunakan range(). Lalu simpan di sebuah variabel bernama kubik.'''