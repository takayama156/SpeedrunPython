# string, list, tuple bisa dikali
print('Ha' * 5)
print([1,2] * 5)
print((1,2) * 5)

a = range(11)
# mengambil elemen yang genap
print(a[::2])
# membuat list terbalik
print(a[::-1])

# mengurutkan list
a = [6, 3, 2, 5, 4, 1]
a.sort()
print(a)

# menciptakan dictionary dengan cara ini
print({'kuadrat_' + str(x): x ** 2 for x in range(5)})

a = 5
b = 7
# menukar dua buah variabel
print('sebelum: a = ' + str(a) + ', b = ' + str(b))
a, b = b, a
print('sesudah: a = ' + str(a) + ', b = ' + str(b))

'''Jujur saja, sebenarnya masih banyak topik maupun tips dan trik yang belum dibahas di sini. Tetapi anda tidak perlu belajar semua hal tetek bengek di Python untuk menjadi seorang coder Python yang handal. Seperti halnya menulis novel, penulis novel yang memenangkan penghargaan bukanlah penulis yang menghapal semua baris di kamus bahasa tetapi penulis yang dapat meramu kata yang dia miliki hingga menciptakan cerita yang dashyat. Begitu juga dengan anda, dengan apa yang anda punya sekarang anda sudah bisa membuat program yang keren, tinggal bagaimana anda meramunya.

Tapi jangan berhenti di sini dulu, di sub-bab berikutnya kita akan belajar tentang class dan pemograman berorientasi objek di Python.'''

'''Perhatikan code di samping, lihatlah seberapa fleksibel dan powerfulnya Python.'''