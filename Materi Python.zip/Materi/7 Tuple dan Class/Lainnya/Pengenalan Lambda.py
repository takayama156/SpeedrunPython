acak = [2, 18, 9, 22, 4,
        17, 24, 8, 12,
        22, 18, 1, 30,
        4, 14, 1, 23,
        51, 8, 31, 13,
        27]

print(filter(lambda x: x > 13 !=0, acak))

'''Kita sudah belajar untuk membuat function yaitu dengan def. Tetapi ada cara lain untuk membuat function, yaitu dengan lambda seperti ini:

lambda x: x % 2 == 0
code di atas sama dengan:

def is_genap(x):
  return x % 2 == 0
Perbedaannya adalah lambda tidak memerlukan nama selayaknya def. Maka karena itu juga function yang dibuat dengan lambda adalah function yang anonim. Anda pun bisa menggunakan lebih dari satu argumen dengan cara seperti ini:

lambda x, y: x + y
yang sama dengan:

def tambah(x, y):
  return x + y
Lambda kekuatannya akan terlihat jika kita menggunakan filter(). Function filter() menerima dua argumen/parameter seperti ini:

list_saya = range(11)
print filter(lambda x: x % 2 == 0, list_saya)
Di argumen pertama dari filter kita berikan sebuah lambda, di argumen keduanya kita berikan list yang akan disaringnya. Lambda yang kita berikan memberikan nilai True jika nilai x adalah genap.'''

'''Mungkin untuk sekarang gunanya lambda belum terlalu jelas buat anda. Tapi itu tidaklah masalah, yang utama sekarang adalah anda tahu bahwa lambda itu ada dan jika anda menemukan code ini di modul orang lain, anda tidak akan terkejut.

Lengkapi function lambda di samping yang hanya akan mencetak angka yang lebih besar daripada 13. Sebagai referensi caranya bagaimana, lihat code di contoh atas yang hanya akan mencetak angka yang genap.'''