# simpan angka 3 dalam bentuk biner di biner_saya
biner_saya = 0b11

print(biner_saya)

# simpan angka 10 dalam bentuk oktal di oktal_saya
oktal_saya = '012'

print(oktal_saya)

# simpan angka 19 dalam bentuk heksa di heksa_saya
heksa_saya = 0x13

print(heksa_saya)

'''Mungkin anda sudah pernah mendengar tentang sistem bilangan biner, oktal, dan heksadesimal. Jika belum bisa dilihat di wikipedia (untuk binary, oktal, dan heksadesimal). Intinya binary adalah sistem angka berbasis 2, oktal berbasis 8 sedangkan heksadesimal berbasis 16. Sementara apa yang umum kita gunakan adalah sistem desimal berbasis 10.

Python pun mendukung operasi untuk angka-angka tersebut selayaknya angka biasa.

Untuk membuat bilangan biner, kita menggunakan awalan 0b di depan angkanya seperti ini:

print 0b10 # bernilai 2 di desimal
print 0b11 + 0b1001 # 3 + 9 = 12
Untuk bilangan oktal, kita menggunakan awalan cukup 0 di depan angkanya seperti ini:

print 010 # bernilai 8 di desimal
print 017 * 023 # menghasilkan 285 di desimal
Awalan 0x di depan angka akan membuat sebuah bilangan heksa seperti ini:

print 0x10 # bernilai 16
print 0xE0 / 0x8 # bernilai 28 di desimal'''

'''Kerjakan soal di samping mengikuti perintah yang ada di komentar!

Jika kesulitan, silahkan lihat petunjuk'''

'''Anda bisa coba-coba alias trial dan error.

Turun satu persatu mulai dari 017 di oktal_saya.

dan lagi turun satu persatu mulai dari 0x19 di heksa_saya.

Untuk binary, coba liat tutorial di atas, ada petunjuk bagaimana menyimpan angka 3 di biner.'''