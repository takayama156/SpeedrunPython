class Kendaraan(object):
  
  bahan_bakar = "bensin"

mobil = Kendaraan()

print(mobil.bahan_bakar)

'''Sebuah class belumlah berguna sebelum kita membuat objek dari class tersebut. Cara membuatnya mudah yaitu seperti ini:

nama_objek = nama_class()
Dengan mengambil contoh dari soal sebelumnya kita bisa membuat sebuah objek dengan cara berikut:

class Gadget(object):
  sumber_energi = "listrik"

hp = Gadget()
Variabel hp adalah sebuah objek yang bertipe-objek (class) Gadget. Variabel hp akan memiliki properti sumber_energi yang bernilai "listrik".

Untuk mengakses properti dari sebuah objek dapat dilakukan dengan cara berikut:

nama_objek.nama_properti
Dengan contoh Gadget kita diatas, untuk mencetak sumber_energi dari hp bagaimana kita melakukannya? Tebakan anda benar:

print hp.sumber_energi
akan mengeluarkan "listrik".'''

'''Buatlah sebuah objek mobil yang merupakan objek dengan class Kendaraan. Lalu print properti bahan_bakar dari mobil.'''