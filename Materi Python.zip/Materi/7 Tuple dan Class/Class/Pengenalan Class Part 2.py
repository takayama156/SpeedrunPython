class Kendaraan(object): 
  bahan_bakar = "bensin"
  
'''Sebelum membuat objek, kita harus membuat dulu tipe objeknya atau bahasa codingnya adalah class. Cara membuat class seperti ini:

class NamaClass(object):
  # segala sesuatu tentang NamaClass 
NamaClass adalah nama class yang anda ingin buat. Sedangkan NamaClass(object) menandakan bahwa anda ingin NamaClass ini merupakan sebuah object. Jika anda ingin membuat objek Gadget, maka kita bisa buat seperti ini:

class Gadget(object):
  sumber_energi = "listrik"
Dengan ini kita mempunyai sebuah tipe objek bernama Gadget. Dan semua objek yang bertipe Gadget akan memiliki sebuah properti yang bernama sumber_energi yang bernilai "listrik".'''

'''Buatlah sebuah class yang bernama Kendaraan.
Class tersebut memiliki properti bernama bahan_bakar yang kita berikan nilai "bensin".
Perhatikan spasi setelah :. Intinya baris setelah : harus mengandung spasi hingga baris yang tidak termasuk di dalam class.'''