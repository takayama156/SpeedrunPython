class Gadget(object):
  pembuat = [] # variabel bersama
  
  def __init__(self):
    self.fitur = [] # variabel pribadi
    
  def tambah_fitur(self, fitur):
    self.fitur.append(fitur)
 
  def tambah_pembuat(self, pembuat):
    self.pembuat.append(pembuat)

hp = Gadget()
tablet = Gadget()

hp.tambah_pembuat("Apple")
tablet.tambah_pembuat("Samsung")

# pembuat di ke dua objek memiliki nilai yg sama
print("hp.pembuat: " + str(hp.pembuat) )
print("tablet.pembuat: " + str(tablet.pembuat))

hp.tambah_fitur("Telepon")
tablet.tambah_fitur("Layar Besar")

# fitur di ke dua objek berbeda
print("hp.fitur: " + str(hp.fitur))
print("tablet.fitur: " + str(tablet.fitur))

'''Tentunya anda masih ingat tentang list dan dictionary. List dan dictionary bisa menjadi sebuah properti di class, tetapi mereka mempunyai perilaku yang berbeda untuk variabel pribadi (di dalam __init__) dan variabel bersama (di luar __init__).

Ketika menjadi sebuah variabel bersama, properti yang merupakan list dan dictionary akan selalu memiliki nilai yang sama di semua objek dari kelas yang sama. Itu dikarenakan list dan dictionary adalah mutable objek. Berbeda misalnya dengan properti yang bukan mutable objek (string, angka, dll.) seperti ini:

class Gadget(object):
  baterai = 100

hp = Gadget()
tablet = Gadget()

hp.baterai = 90
print tablet.baterai # 100
print hp.baterai # 90
Perhatikan bahwa walaupun hp mengubah nilai baterai menjadi 90 tetapi nilai baterai dari tablet tetaplah 100. Hal ini tidak akan terjadi jika baterai merupakan sebuah list.'''

'''Perhatikan properti pembuat yang merupakan sebuah list di class Gadget.
Perhatikan juga properti fitur yang juga merupakan sebuah list.
Perhatikan output keduanya.
Apakah anda memperhatikan perbedaannya?'''