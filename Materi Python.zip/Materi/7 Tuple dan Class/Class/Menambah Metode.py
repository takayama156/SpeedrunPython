class Kendaraan(object):
  
  km = 0
   
  def __init__(self, nama):
    self.nama = nama
  
  def jalan(self, jarak):
    self.km = self.km +jarak


mobil = Kendaraan('Mobil')
motor = Kendaraan('Motor')

# panggil jalan() di sini
mobil.jalan(100)
print(mobil.km)

motor.jalan(60)
print(motor.km)

'''Selain metode __init__() tentunya kita bisa menambah metode lain yang akan membuat objek kita lebih hidup. Sintaksnya sama persis:

class Gadget(object):

 baterai = 100

 def gunakan(self, waktu):
  self.baterai = self.baterai - waktu
Di contoh atas kita simulasikan kapasitas baterai dengan properti baterai. Dan juga setiap kali sebuah objek Gadget di-gunakan() sebanyak waktu, kita buat baterai akan berkurang sebanyak waktu.

Kita bisa menggunakan metodenya seperti berikut:

hp = Gadget()

print hp.baterai # 100

hp.gunakan(20)

print hp.baterai # 80'''

'''Di Kendaraan, buat sebuah properti bernama km yang kita isi dengan nilai 0.
Tambahkan sebuah di metode bernama jalan() yang menerima parameter bernama jarak. Ingat berikan juga parameter self sebagai parameter pertamanya.
Di jalan(), kita lakukan penambahan kepada properti km sebanyak jarak.
Di akhir dari code, panggil metode jalan() dari motor atau mobil. Jangan lupakan untuk menggunakan parameter di dalam jalan().'''

'''Di jalan(self, jarak), kodenya akan mirip seperti ini:

def metode(self, j):
  self.k = self.k + j'''