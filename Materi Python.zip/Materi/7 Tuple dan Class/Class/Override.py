class Kendaraan(object):
  
  def __init__(self, nama):
    self.nama = nama
    self.penumpang = []
    
  def tambah_penumpang(self, nama_penumpang):
    self.penumpang.append(nama_penumpang)
    
class Motor(Kendaraan):
  
  # melakukan definisi ulang terhadap metode ini
  def tambah_penumpang(self, nama_penumpang):
    if len(self.penumpang) < 2:
      # memanggil kembali metode asli dari Kendaraan
      super(Motor, self).tambah_penumpang(nama_penumpang)
    else:
      # Jika sudah ada dua penumpang maka kita tidak masukkan
      print("Maaf {}, anda tidak bisa masuk".format(nama_penumpang)) 
    
motor = Motor('CSMotor')
motor.tambah_penumpang('Raisa')
motor.tambah_penumpang('Isyana')
motor.tambah_penumpang('Afgan')

print("Penumpang : " + str(motor.penumpang))

'''Dalam penurunan kelas kita bisa melakukan penggantian metode orang-tua (parents) di kelas anak (children). Caranya mudah sekali cukup tulis ulang nama metodenya yang sama seperti ini contohnya:

class Ortu(object):
  def metode_anu(self)
    # lakukan anu

class Anak(Ortu):
  def metode_anu(self)
    # lakukan anu menurut Anak
Di contoh atas kita punya metode_anu lagi di kelas Anak. Nantinya setiap objek dari Anak akan merujuk ke metode_anu di Anak alih-alih di Ortu. Tetapi, objek dari kelas Ortu tetap akan menggunakan metode_anu dari kelas Ortu. 

Lalu bagaimana jika kedua metode tersebut hanya berbeda sedikit saja? Kita gunakan super(). Fungsi super() berguna untuk memanggil metode dari kelas orang tua. Sehingga kita bisa melakukan hal yang unik di kelas anak dan setelah selesai panggil lagi metode orangtuanya. Contohnya seperti ini:

class Anak(Ortu):
  def metode_anu(self)
    # lakukan anu menurut Anak
    # setelah selesai kita panggil
    super(Anak, self).metode_anu()
Perhatikan baik-baik sintaks function super().'''

'''Di contoh samping lihat bagaimana kita menggantikan metode tambah_penumpang() dari Kendaraan.

Perhatikan baik-baik cara kita menolak menambah penumpang di saat penumpang sudah ada 2. Tidak perlu lakukan apapun cukup jalankan saja.'''