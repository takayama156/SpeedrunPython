class Kendaraan(object):
  
  def __init__(self, nama):
    self.nama = nama
    self.penumpang = []
    
  def tambah_penumpang(self, nama_penumpang):
    self.penumpang.append(nama_penumpang)
    
class Mobil(Kendaraan):
  def tambah_penumpang(self, nama_penumpang):
    if len(self.penumpang) < 4:
      super(Mobil, self).tambah_penumpang(nama_penumpang)
    else:
      print("maaf {}, anda tidak bisa masuk".format(nama_penumpang))
      
mobnas = Mobil('CodeSayaCar')
mobnas.tambah_penumpang('Raisa')
mobnas.tambah_penumpang('Isyana')
mobnas.tambah_penumpang('Dian')
mobnas.tambah_penumpang('Agnes')
mobnas.tambah_penumpang('Afgan')

print("Penumpang : " + str(mobnas.penumpang))

'''Mari kita buat praktekan cara untuk mengganti metode kelas orang tua di unit ini.'''

'''Mari kita override metode tambah_penumpang() di Mobil dengan cara mendefinisikan ulang metode tersebut.

Sekarang jika jumlah penumpang sudah 4, maka kita tidak akan masukkan penumpang tersebut ke Mobil.'''

'''Sintaksnya seperti ini: 

super(KelasAnak, self).metodenya(argumen)'''