class Kendaraan(object):

  def __init__(self, nama):
    self.nama = nama
    self.penumpang = []
    
  def tambah_penumpang(self, nama_penumpang):
    self.penumpang.append(nama_penumpang)
    
# membuat class Mobil yang merupakan turunan Kendaraan
class Mobil(Kendaraan):
  pintu_terbuka = False
  
  def buka_pintu(self):
    self.pintu_terbuka = True
  def tutup_pintu(self):
    self.pintu_terbuka = False
    
mobnas = Mobil("MobilSaya")

# mobnas akan memiliki properti dari Kendaraan
mobnas.tambah_penumpang("Raisa")
print("Penumpang: " + str(mobnas.penumpang))
# dan memiliki properti Mobil
mobnas.buka_pintu()
print("Pintu terbuka: " + str(mobnas.pintu_terbuka))

'''Inheritance (warisan atau turunan) adalah sebuah konsep yang penting di dalam Python. Inheritance adalah sebuah proses dimana sebuah class mengambil semua properti dan semua metode dari kelas lain.

Mari kita ambil contoh dari unit sebelumnya tentang class Kendaraan. Sebelumnya kita membuat motor dan mobil berdasarkan Kendaraan. Tetapi kita akan mengalami masalah karena motor dan mobil walaupun memiliki banyak kesamaan tetapi mereka sebenarnya berbeda. Solusinya adalah kita membuat kelas baru bernama Mobil dan Motor yang merupakan turunan Kendaraan. Di Kendaraan kita definisikan semua metode dan semua properti yang umum dimiliki sebuah kendaraan. Lalu di Mobil dan Motor kita definisikan metode dan properti yang unik untuk masing-masing kelas tersebut.'''

'''Perhatikan code dan komentar di samping. Lihat baik-baik class Mobil, di unit berikutnya anda akan diminta untuk membuat class Motor yang merupakan turunan Kendaraan. Untuk unit ini tidak ada tugas, jalankan saja.

Inheritance membuat pengembangan dari sebuah program mudah karena artinya coder gak perlu nulis properti dan metode yang sama berulang-ulang untuk banyak '''

'''Penulisan nama kelas menurut perjanjian para coder Python sedunia adalah huruf pertama huruf kapital.'''