class Kendaraan(object):

  def __init__(self, nama):
    self.nama = nama
    self.penumpang = []
    
  def tambah_penumpang(self, nama_penumpang):
    self.penumpang.append(nama_penumpang)
    
# buatlah class Motor yang merupakan turunan Kendaraan
class Motor(Kendaraan):
  standar_terpasang = False
  
  def pasang_standar(self):
    self.standar_terpasang = True
    
'''Dari unit sebelumnya anda pasti sudah dapat menebak bahwa sintaks turunan seperti ini:

class Pewaris(PemberiWarisan):
  # dan lain-lain
Sering sekali di programming 'Pewaris' disebut sebagai kelas anak (children) dan 'PemberiWarisan' disebut sebagai kelas orang tua (parent).

Dan benar juga tebakan anda, sebelumnya saat anda melakukan Gadget(object) sebenarnya anda membuat turunan Gadget berdasarkan kelas object.

Buatlah sebuah kelas bernama Motor yang merupakan turunan dari Kendaraan.
Berikan sebuah properti bernama standar_terpasang yang bernilai False.
Buatlah sebuah metode yang bernama pasang_standar(self) yang mengubah properti standar_terpasang menjadi True.'''