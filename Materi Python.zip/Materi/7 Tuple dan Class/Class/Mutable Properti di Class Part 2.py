class Kendaraan(object):
  penumpang = []
  
  def __init__(self, nama):
    self.nama = nama
    self.penumpang=[]
 
  def tambah_penumpang(self, nama_penumpang):
    self.penumpang.append(nama_penumpang)
    
# Code di bawah ini untuk anda memeriksa sendiri
# apakah code anda sudah benar
mobil = Kendaraan("Mobil")
motor = Kendaraan("Motor")

mobil.tambah_penumpang("Michael Schumacher")
mobil.tambah_penumpang("Rio Haryanto")

motor.tambah_penumpang("Nico Rosberg")

# Hasilnya haruslah berbeda
print(motor.penumpang)
print(mobil.penumpang)

'''Sekarang saatnya anda mengaplikasikan apa yang telah anda pelajari sebelumnya!'''

'''Di code samping mari kita perbaiki penumpang karena tak seharusnya penumpang mobil masuk juga ke motor. Ini terjadi karena penumpang adalah sebuah mutable objek.

Cara memperbaikinya mudah saja yaitu cukup buat properti penumpang menjadi sebuah variabel pribadi.'''