class NamaKelas(object):
  
  properti_bersama = "Nilai Bersama"
  
  # fungsi inisialisasi
  def __init__(self, parameter_1, parameter_2):
    self.properti_pribadi_1 = parameter_1
    self.properti_pribadi_2 = parameter_2
    self.properti_pribadi_3 = ("Nilai", "Tuple", "Pribadi")
  
  def metode_lain(self):
    # lakukan sesuatu, contohnya
    print("metode lain dipanggil!")

objek = NamaKelas("nilai string", True)

print(objek.properti_bersama)
print(objek.properti_pribadi_1)
print(objek.properti_pribadi_2)
print(objek.properti_pribadi_3)

objek.metode_lain()

'''Yang kita lakukan di kelas sejauh ini menggunakan paradigma pemograman yang terstruktur (structured programming). Ada paradigma lain yang didukung oleh Python yaitu pemograman berorientasi objek (OOP: Object Oriented Programming). Dan dasar dari OOP adalah tentu saja objek.

Sejauh ini tanpa anda sadari anda telah menggunakan objek. Apa anda ingat tentang String? Yup, string adalah objek! Dictionary masih ingat? Benar, objek juga!'''