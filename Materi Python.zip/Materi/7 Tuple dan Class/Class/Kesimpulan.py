# 1. Membuat Class
class Kendaraan(object):
  # 2. Variable Bersama
  km = 0
  # 3. metode inisialisasi
  def __init__(self, nama):
    # 4. variabel pribadi
    self.nama = nama
    # 5. mutable objek sebagai variable pribadi
    self.penumpang = []
  # 6. metode lainnya
  def tambah_penumpang(self, penumpang):
    self.penumpang.append(penumpang)
  
# 7. Membuat turunan
class Mobil(Kendaraan):
  # 8. variabel bersama khusus untuk Mobil
  pintu_terbuka = False
  # 9. metode khusus untuk Mobil
  def buka_pintu(self):
    self.pintu_terbuka = True
  # 10. override metode orang tua
  def tambah_penumpang(self, penumpang):
    if len(self.penumpang) < 4:
      # 11. memanggil metode orang tua
      super(Mobil, self).tambah_penumpang(penumpang)

# 12. membuat objek
mobnas = Mobil("CarSaya")
# 13. memanggil metode
mobnas.buka_pintu()
mobnas.tambah_penumpang("Ganis")
# 14. mengakses properti
print(mobnas.penumpang)

'''Selamat, anda sudah menguasai konsep dari OOP! Di Python kita tidaklah harus menggunakan OOP, di CodeSaya sendiri dalam mengembangkan platform ini tidak selalu menggunakan OOP. Jika dirasa programnya akan rumit maka gunakanlah OOP, jika tidak pemograman terstruktur sudah sangat memadai.'''

'''Ada banyak yang telah kita pelajar di sub-bab ini loh! Kurang lebih ada 14 poin, mungkin anda perlu scroll ke bawah untuk melihat semua codenya. Silahkan anda perhatikan code di samping untuk mengingat-ingat lagi apa yang telah anda pelajari.'''