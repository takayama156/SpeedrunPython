class Kendaraan(object):

    bahan_bakar = "bensin"
    
    def __init__(self, nama):
      self.nama = nama

mobil = Kendaraan("Mobil")
motor = Kendaraan("Motor")

print(mobil.nama)
print(motor.nama)

'''Keren! Sekarang kita sudah bisa membuat objek! Tetapi objek yang anda buat belum unik satu sama lainnya, mari kita buat mereka sedikit berbeda.

class Gadget(object):

  sumber_energi = "listrik"

  def __init__(self, nama_gadget):
    self.nama = nama_gadget
function di dalam sebuah class disebut sebagai sebuah metode class tersebut. Di sini kita buat sebuah metode bernama __init__. Metode dengan nama ini sudah direservasi oleh Python sebagai metode yang dipanggil saat kita membuat sebuah objek. Di setiap metode class harus selalu ada self sebagai parameter pertamanya. Variabel self merujuk kepada objek dari class tersebut. Di metode ini kita tambah sebuah parameter bernama nama_gadget. Di metode ini juga kita membuat properti nama dengan sintaks self.nama dan memberikan nilai dari nama_gadget.

Karena kita telah menambah parameter nama_gadget di fungsi __init__() berarti saat membuat objek baru kita harus berikan sebuah parameter seperti ini:

hp = Gadget("Android")
Dengan code di atas, properti nama dari hp akan menjadi "Android", sementara jika kita buat seperti ini:

tablet = Gadget("iOS")
Properti nama dari tablet akan menjadi "iOS". dan nama termasuk sebagai variabel pribadi. Sementara itu sumber_energi yang bernilai 'listrik' di kedua variabel tersebut disebut sebagai variabel bersama.'''

'''Mari kita buat __init__() yang menerima sebuah parameter bernama nama selain self.
Di metode __init__() kita set properti self.nama menjadi nama.
Perbaiki cara membuat objek mobil-nya. Masukkan parameter "Mobil".
Buat juga sebuah objek bernama motor yang diberikan parameter "Motor".'''