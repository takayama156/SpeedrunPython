print("Python muncul pertama kali pada tahun " + str(1991))

'''Terkadang kita butuh untuk menggabungkan sebuah string dengan sesuatu hal yang bukan string, untuk melakukan hal tersebut kita harus mengkonversinya ke string seperti ini:

print "Dia makan " + str(4) + " biji"
Code di atas akan mencetak "Dia makan 4 biji"

Metode str() mengubah non-string menjadi string. Di contoh atas, dengan str() kita mengubah 4 yang semula adalah angka menjadi string.'''

'''Untuk mengubah angka 17 menjadi string kita menggunakan str(17)'''