info = "Pencipta Python berasal dari Belanda"
print((info))

'''Hebat! Sekarang mari setelah kita mencetak string, saatnya kita mencetak variabel!'''

'''Buatlah sebuah variabel bernama info dan berikan nilai string yaitu "Pencipta Python berasal dari Belanda"
print variabel tersebut di baris berikutnya!'''

'''Buat variabelnya seperti ini:

namanya = "Guido'''