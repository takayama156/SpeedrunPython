kalimat = "Rangga berteriak \"Senyumlah!\" setelah melihat jones."

print(kalimat)

'''Terkadang ada karakter yang bisa menyebabkan masalah. Contohnya:

"Dian berkata "Jangan sedih." untuk menghibur kamu yang jomblo."
Code di atas menyebabkan Python error karena ada tanda kutip " di tengah-tengah kalimat. Begini caranya:

"Dian berkata \"Jangan sedih.\" untuk menghibur kamu yang jomblo."
Cukup ubah " menjadi \".

 Instruksi:
Perbaiki string di samping!'''

'''Selain mengubah " menjadi \", anda juga bisa menggunakan kombinasi " dan ' untuk memperbaiki string di tersebut.'''