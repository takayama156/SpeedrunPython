""" 
String "PYTHON" memiliki 6 karakter,
diberi nomer 0 hingga 5 seperti berikut

+---+---+---+---+---+---+
| P | Y | T | H | O | N |
+---+---+---+---+---+---+
  0   1   2   3   4   5

Jika anda ingin mencetak "Y", anda mencetaknya seperti ini
python = "PYTHON"
print python[1] # selalu berhitung dari 0!
"""
website = "codesaya.com"

huruf_ke_1 = website[0]

huruf_ke_4 = website[3]

huruf_ke_9 = website[8]

print(huruf_ke_4)

'''Setiap karakter di string dapat diakses dengan sebuah angka. Angka ini disebut dengan indeks. Liat contoh di editor dan juga contoh di bawah ini:

kata = "codesaya"

c = kata[0]

d = kata[2]
Di contoh atas, kita menciptakan sebuah variabel c yang memiliki nilai "c". Karena karakter dengan indeks ke 0 di string "codesaya" adalah "c".

Sementara itu, variabel d akan bernilai "d", karena itu adalah indeks ke 3 di string "codesaya".

Di Python, kita menghitung indeks dimulai dari kosong bukan dari satu.''''

'''Buat variabel huruf_ke_4 dan huruf_ke_9 agar memiliki nilai yang diminta. huruf_ke_1 telah dibuat untuk menjadi contoh bagi anda.'''