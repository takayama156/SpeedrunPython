tokoh = "amogus"

'''Tipe data berikutnya yang anda akan pelajari adalah string. String digunakan untuk menyimpan karakter, kata, kalimat hingga paragraph. Contohnya seperti ini:

nama = "Cinta"
umur = "34"
ucapan = "Pagi selalu menawarkan cerita yang baru"
website = "http://codesaya.com"
Di contoh atas, kita membuat variabel nama, umur, ucapan, dan juga website yang merupakan sebuah string.

String selalu dimulai dan diakhiri dengan tanda " atau '.

Perhatikan bahwa di sini umur bukanlah angka karena menggunakan ".'''

'''Buat sebuah variabel yang bernama tokoh dan berikan sebuah nama.

Tidak ada perbedaan antara menggunakan " atau '.'''