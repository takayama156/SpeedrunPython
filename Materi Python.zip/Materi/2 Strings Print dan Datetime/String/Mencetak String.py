print("Ini bukan tentang ular")

'''Tempat dimana anda menulis code selama ini disebut editor.

Di bawahnya disebut console atau output.

print gunanya untuk mencetak ke console.'''

'''Cetak "Ini bukan tentang ular" ke console.'''