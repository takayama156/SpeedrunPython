print("Python " + "Software " + "Foundation")

'''Anda telah tahu tentang string dan anda telah tahu tentang operasi aritmetika. Sekarang mari kita gabungkan keduanya! Contohnya seperi ini:

print "Python " + "seru " + "kan?"
code di atas akan mengeluarkan kalimat "Python seru kan?".

Operator + di antara string akan merangkai mereka. Perhatikan kita menggunakan spasi di dalam tanda petik setelah "Python" dan "seru". Karena jika tidak ada spasi maka mereka akan berhimpitan!'''

'''Sekarang anda bisa coba, print rangkaian string-string "Python ", "Software ", dan "Foundation" seperti pada contoh di atas.

Pastikan anda menggunakan spasi di "Python " dan "Software ".'''