ucapan = "Nama Python dipilih karena pembuatnya menyukai acara TV Monty Python."

# panjang ucapan simpan di sini dengan len()
panjang = len(ucapan)

# hasilkan huruf besar semua dengan upper()
besar = ucapan.upper()

# hasilkan huruf kecil semua dengan lower()
kecil = ucapan.lower()

print(panjang)
print(besar)
print(kecil)

'''Saatnya mengimplementasikan apa yang telah anda pelajari di unit sebelumnya!'''

'''codenya mirip-mirip seperti ini:

p = len(u)

b = u.upper()

k = u.lower()'''