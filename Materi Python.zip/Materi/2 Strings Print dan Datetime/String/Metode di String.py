fakta = "Belajar Python di CodeSaya itu menyenangkan..!"

print(len(fakta))

print(fakta.lower())

print(fakta.upper())

'''Setelah kita mengetahui bagaimana caranya untuk menyimpan string, sekarang kita belajar bagaimana caranya untuk memodifikasinya.

Metode di string memperbolehkan anda untuk mengerjakan tugas tertentu di string.

Sekarang kita lihat tiga metode di bawah:

len() - menghasilkan panjang dari sebuah string,
lower() - menghasilkan string dengan karakter huruf kecil,
upper() - menghasilkan string dengan karakter huruf kapital.'''

'''Perhatikan code di samping, jalankan dan lihat outputnya. Apakah anda mengerti? ^^'''