negara = "Indonesia"

ibukota = "Jakarta"

motto = "Bhinneka Tunggal Ika"

tanggal_kemerdekaan = "17 Agustus 1945"

'''Oke mari kita berlatih lagi tentang strings.

 Instruksi:
Jawab semua variabel di samping menggunakan strings. Jika bingung apa jawabannya liat di wikipedia Indonesia.'''