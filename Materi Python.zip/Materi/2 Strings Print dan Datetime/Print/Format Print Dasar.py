nama = "Komodo"
spesies = "kadal"
tempat = "Nusa Tenggara"

print("{} adalah spesies {} terbesar di dunia yang hidup di {}." .format(nama, spesies, tempat))

'''Ketika  kita ingin mencetak sebuah variabel dengan string, ada cara lain untuk menggabungkannya.

nama = "Guido"

print "Halo {}".format(nama)
Output di atas akan mengeluarkan "Halo Guido". Dengan menggunakan .format kita mengubah {} di dalam "Halo {}" dengan variabel nama.

Kita bisa menggunakan lebih dari satu {} di dalam string loh, seperti ini:

satu = "Satu"

dua = "Dua"

print "{} {}".format(satu, dua)
Apa anda bisa menebak outputnya? Yup, contoh di atas akan mengeluarkan "Satu Dua".'''

'''Di akhir baris 5, gunakan .format() agar code mencetak kalimat yang baik dan benar. Untuk soal ini, berikan 3 variabel di .format() karena ada tiga {}.'''

'''Nanti code anda akan seperti ini:

print "{} {} {}".format(a, b, c)'''