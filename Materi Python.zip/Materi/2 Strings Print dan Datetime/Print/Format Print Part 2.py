nama = "Sumatera"
nama_latin = "Panthera tigris sumatrae"

teks = "Harimau {0} ({1}) habitat aslinya di pulau {0}"

print(teks.format(nama, nama_latin))

'''Dengan .format() banyak hal yang bisa anda lakukan! Misalnya jika anda ingin mengganti urutan variabelnya:

satu = "Pergi"
dua = "Kamu"
print "{0} {1}!".format(satu, dua)
print "{1} {0}!".format(satu, dua)
Yang pertama akan mengeluarkan "Pergi Kamu!", sedangkan yang kedua mengeluarkan "Kamu Pergi!".

Dengan memberikan angka di dalam {} kita bisa mengatur urutannya tanpa harus mengubah urutan variabelnya. Canggih kan?

Selain mengganti urutan, kita juga bisa mengulang variabel yang sama di dalam string:

nama = "Hodor"
print "{0}! {0}!".format(nama)
Yang akan mengeluarkan output "Hodor! Hodor!".

Seperti biasa, kita memulai perhitungan indeks dari 0.

Di dalam variabel teks, ubah tanda tanya ? ke angka indeks yang tepat agar outputnya mengeluarkan:

 ""Harimau Sumatera (Panthera tigris sumatrae) habitat aslinya di pulau Sumatera"
 
 Perhitungan indeks dimulai dari 0, dan indeks dapat digunakan lebih dari satu kali.'''