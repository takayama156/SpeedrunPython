print("Anda sudah bisa mencetak string...")

selain_itu = "juga sudah bisa mencetak variabel..."

print(selain_itu)

print("Merangkai " + "kata " + "menjadi " + "kalimat...")

print("Bahkan angka seperti " + str(1) + ", " + str(2) + ", dst pun dirangkai...")

anda = "Anda"

terhebat = "terhebat"

print("Apakah {0} tahu siapa yang {1}? {0}! {0}!".format(anda, terhebat))

'''Saatnya mereview apa yang telah anda pelajari!'''

'''Lihat code di samping. Itu semua kita pelajari di sub-bab ini loh! Ubah sesuka hati anda, kali ini tidak diperiksa! Jika sudah siap dan mengerti, silahkan menuju unit berikutnya!'''

'''coba jalankan code ini:

print '{:_>10}'.format('kanan')

dan ini:

print '{:-^10}'.format('tengah')

.format() itu sangat powerful bukan? ^^'''