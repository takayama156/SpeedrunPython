from datetime import datetime

sekarang = datetime.now()

print(sekarang)

'''Sering kali kita ingin mengetahui waktu ketika sesuatu hal terjadi. Di dunia nyata kita melihat jam dan kalendar. Kalo di Python, kita punya datetime. datetime adalah sebuah library atau modul yang dipanggil jika anda membutuhkan segala operasi yang berhubungan demi waktu. Cara memanggilnya seperti ini:

from datetime import datetime

Apa sih maksudnya "memanggil" datetime itu? Memanggil (meng-import) datetime  adalah memberi tahu Python bahwa kita akan menggunakan fungsi dari modul datetime di program kita. Setelah dipanggil, semua fungsi yang ada di datetime dapat kita gunakan. Apa anda ingat str() dan len() yang telah kita pelajari sebelumnya? Yup, itu adalah fungsi yang otomatis dipanggil oleh Python. datetime tidak otomatis dipanggil, kita harus melakukannya secara manual.'''

'''Coba panggil library datetime! Lihat tutorial di atas untuk mengetahui caranya.'''