from datetime import datetime
sekarang = datetime.now()

sekarang_tahun = sekarang.year

sekarang_bulan = sekarang.month

sekarang_hari = sekarang.day

print("{0}-{1}-{2}".format(sekarang_tahun, sekarang_bulan, sekarang_hari))

'''Apakah anda memperhatikan bahwa output dari datetime.now() itu seperti ini 2016-05-05 13:24:45.904426. Bagaimana jika kita hanya perlu tahun, bulan, dan hari saja?

from datetime import datetime
sekarang = datetime.now()

tahun = sekarang.year
bulan = sekarang.month
hari = sekarang.day
Di baris ke tiga, kita mengambil properti year dari variabel sekarang dan menyimpannya di tahun. Begitu juga halnya dengan bulan yang mengambil month, dan hari yang mengambil day dari sekarang.'''

'''Di baris ke 4 dan seterusnya, berikan sekarang_tahun, sekarang_bulan, dan sekarang_hari nilai yang tetap dengan menggunakan properti dari variabel sekarang.'''