from datetime import datetime

kini = datetime.now()
jam = kini.hour
menit = kini.minute
detik = kini.second

print("{0}:{1}:{2}".format(jam, menit, detik))

'''Kita juga bisa mendapatkan jam, menit, dan detik loh dari datetime. Seperti ini caranya:

from datetime import datetime
n = datetime.now()

print n.hour
print n.minute
print n.second
Tidak perlu dijelaskan panjang lebar, pasti anda mengerti karena mirip sekali dengan unit-unit sebelumnya, hanya saja sekarang kita mengambil properti hour, minute, dan second dari now().'''

'''Tarik napas, unit ini akan buat kamu gregetan!

Kita akan melakukan operasi yang berhubungan dengan waktu, jangan lupa untuk mengimpor datetime.
Buat variabel bernama kini dan berikan waktu sekarang dengan datetime,
Buat variabel bernama jam dan berikan properti hour dari kini,
Buat variabel bernama menit dan berikan properti minute dari kini,
Buat variabel bernama detik dan berikan properti second dari kini,
print waktu sekarang dengan format "jam:menit:detik" dengan fungsi .format().'''