from datetime import datetime
sekarang = datetime.now()

sekarang_tahun = sekarang.year
sekarang_bulan = sekarang.month
sekarang_hari = sekarang.day

print("{0}/{1}/{2}".format(sekarang_hari, sekarang_bulan, sekarang_tahun))

'''Apakah anda masih ingat tentang format() dari sub-bab sebelumnya? Yup kita akan menggunakannya untuk mencetak tanggal, seperti ini:

from datetime import datetime
n = datetime.now()

print "{}-{}-{}".format(n.year,
 n.month, n.day)
code di atas akan mencetak tanggal seperti ini 2016-4-5 jika sekarang adalah 5 April 2016'''

'''Di baris berikutnya, print tanggal sekarang dengan format seperti ini: hari/bulan/tahun'''