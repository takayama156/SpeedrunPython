from datetime import datetime
sekarang = datetime.now()
print(sekarang)

'''Kita bisa menggunakan sebuah fungsi bernama datetime.now() untuk mengembalikan waktu dan tanggal sekarang, seperti ini:

from datetime import datetime

print datetime.now()
Garis pertama mengimpor datetime sehingga kita dapat menggunakan. Setelah diimpor, kita bisa menggunakan semua fungsi di datetime dengan notasi titik ..

Garis kedua, kita memanggi fungsi di dalam datetime yaitu now(). Untuk memberitahu bahwa kita menggunakan now()-nya dari datetime, kita menggabungkan datetime dengan now() melalui notasi titik.'''

'''Ciptakan variabel sekarang dan simpan nilai datetime.now() ke variabel tersebut.
Lalu di baris berikutnya cetak dengan print variabel sekarang.'''