harga = 15000

print("A: Harga kudanya berapa ya?")
print("B: " + str(harga))

if harga <= 1500:
   print("A: Kita borong..!!")
   print("B: Terimakasih")
else:
   print("A: Bisa dikurangi harganya?")
   print("B: Tidak bisa.")

print("A: Selamat tinggal.")

'''Lihat code di bawah:

if harga > 1000:
  print "Kita beli"
else:
   print "Kita jual"
print "selesai"
Apa anda bisa tebak apa yang akan terjadi jika harga bernilai di bawah 1000? Benar, "Kita jual" akan tercetak! Itulah gunanya else.

Jika pernyataan di if bernilai False, maka code yang akan dijalankan adalah code di else. Perhatikan lagi spasi di baris setelah else, baris yang menggunakan spasi setelah else adalah blok code yang akan dijalankan.'''

'''Lihat contoh di samping. Apakah anda bisa menebak mana saja yang tercetak? Lalu jalankan!

Sekarang ubah variabel harga menjadi di atas 1500 dan jalankan lagi! Apakah ada perubahan?'''