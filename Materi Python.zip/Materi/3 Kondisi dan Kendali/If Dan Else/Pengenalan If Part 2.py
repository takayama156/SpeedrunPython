jumlah = 100

if jumlah == 100:
    print("ini tercetak")

if jumlah < 100:
    print("ini tidak tercetak")
    
'''Sekarang saatnya anda mempraktekan apa yang telah anda pelajari di unit sebelumnya.'''

'''Di baris ke 3 dan 6 ada if yang belum lengkap. 

Untuk baris ke 3 buat persamaan dengan jumlah yang membuat print "ini tercetak" dieksekusi. 
Sedangkan di baris ke 6 buat persamaan dengan jumlah yang membuat print "ini tidak tercetak" tidak dieksekusi.
Lihat petunjuk jika anda mengalami kesulitan.

if j > 100000:
    print "Hmmm..."'''