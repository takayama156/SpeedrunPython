harga = 500

print("A: Harga kudanya berapa ya?")
print("B: " + str(harga))

if harga < 1500:
   print("A: Kita borong..!!")
   print("B: Terimakasih")

print("A: Selamat tinggal.")

'''if berfungsi untuk memeriksa jika suatu kondisi benar (True) maka code tertentu akan dijalankan. Penulisannya seperti ini:

if harga < 1000:
   print "Kita beli"

print "selesai"
Di contoh ini, jika harga-nya di bawah 1000, maka code akan mencetak "Kita beli", jika harga di tidak dibawah 1000 maka hanya "selesai" yang akan tercetak.

Perhatikan cara penulisannya, kita menggunakan titik dua : dan ada spasi di sebelum print "Kita beli". Nah spasi itu gunanya untuk memberi tahu Python bahwa kita ingin "Kita beli" tercetak jika harga dibawah 1000.'''

'''Lihat contoh di samping. Apakah anda bisa menebak mana saja yang tercetak? Lalu jalankan!

Sekarang ubah variabel harga menjadi di bawah 1500 dan jalankan lagi! Apakah ada perubahan?'''

'''Selain True dan False, if pun menerima angka. 0 dianggap False dan apapun selain 0 adalah True. Sehingga:

if 0:
  # tidak dijalankan
sama dengan:

if False:
 # tidak dijalankan
selain angka 0 (termasuk minus) maka akan dianggap True:

if 1:
 # dijalankan'''