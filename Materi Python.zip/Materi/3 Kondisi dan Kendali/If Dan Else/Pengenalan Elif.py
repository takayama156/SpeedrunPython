harga = 1200

print("A: Harga kudanya berapa ya?")
print("B: " + str(harga))

if harga < 1000:
  print("A: Kita beli 4 ekor")
elif harga < 1500:
  print("A: Kita beli 2 ekor")
else:
  print("A: Bisa dikurangi harganya?")
  print("B: Tidak bisa.")

print("A: Selamat tinggal.")

'''Keren, di unit sebelumnya kita sudah bisa menentukan untuk memberikan pujian "Bagus" saat nilai di atas 7 dan "Lumayan" saat nilai di bawah atau sama dengan 7. Tetapi itu artinya nilai 2 atau 3 pun kita bilang "Lumayan" sama dengan nilai 6 atau 7. Tapi itu tidak adil kan? Bagaimana untuk membedakannya? Kita gunakan elif, seperti berikut:

if nilai > 7:
    print "Bagus"
elif nilai > 5:
    print "Lumayan"
else:
    print "Jelek"
elif adalah gabungan else dan if. Secara bahasa Indonesia else if artinya: "Jika if sebelumnya bernilai False, maka jalankan code ini jika if ini True". Dengan code di atas, nilai dibawah atau sama dengan 5 akan dibilang jelek. Sedangkan nilai 6 atau 7 akan dibilang lumayan.'''

'''Di baris ke 8 dan 9, buatlah elif yang membandingkan harga kurang dari 1500.
Jika benar maka cetaklah "A: Kita beli 2 ekor". Perhatikan spasinya.
Coba jalankan saat harga sama dengan 800.
Ubah harga ke 2000 dan jalankan. Lihat outputnya.
Ubah harga ke 1200 dan jalankan lagi. Lihat outputnya.'''