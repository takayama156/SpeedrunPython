nilai = 6

# lengkapi code dibawah sesuai instruksi

if nilai > 7:
  print("Bagus")
else:
  print("Lumayan")
  
'''Sekarang mari kita berlatih if dan else!'''

'''Berikan nilai untuk variabel nilai kurang atau sama dengan 7.
Tambakan else di baris ke 7.
Di dalam else, perintahkan untuk menuliskan (print) "Lumayan".'''

'''Ingat dari unit sebelumnya, bentuknya if else itu seperti ini..

if sesuatu:
   # maka sesuatu
else:
   # maka bukan sesuatu'''