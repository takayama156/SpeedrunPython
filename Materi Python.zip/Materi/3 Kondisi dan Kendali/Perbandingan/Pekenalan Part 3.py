# Buat perbandingan_satu memiliki nilai True dengan ==
perbandingan_satu = 5 * 0 == 0

# Buat perbandingan_dua memiliki nilai False dengan !=
perbandingan_dua = 20 != 20

# Buat perbandingan_tiga memiliki nilai True dengan <
perbandingan_tiga = 5 < 10

# Buat perbandingan_empat memiliki nilai False dengan <=
perbandingan_empat = 200 <= 100

# Buat perbandingan_lima memiliki nilai True dengan >
perbandingan_lima = 10 > 5

# Buat perbandingan_enam memiliki nilai False dengan >=
perbandingan_enam = 9 >= 100

print(perbandingan_enam)

'''Kita bisa berikan nilai False atau True di sebuah variabel seperti unit sebelumnya. Tapi kita juga bisa loh langsung memberikan perbandingannya ke variabel, seperti ini:

perbandingan = 2 > 1
nantinya perbandingan akan menjadi sebuah boolean yang memiliki nilai True.'''