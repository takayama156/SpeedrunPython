print(11 == 1)

print("CodeSaya" == "Python")

print(5 == 5)

print("HODOR" == "hodor")

print(100 < (10*10))

'''Sekarang mari kita lihat operator apa yang bisa kita gunakan untuk perbandingan:'''

'''Sama dengan ==
Tidak sama dengan !=
Kurang dari <
Kurang atau sama dengan <=
Lebih dari >
Lebih atau sama dengan >=
Dengan ini kita bisa membandingkan sebuah nilai dengan nilai yang lainnya. Jika perbandingannya benar, maka akan menghasilkan nilai True. Sedangkan jika salah maka akan menghasilkan nilai False.

Perhatikan bahwa == gunanya untuk membandingkan, sedangkan = gunanya untuk memberikan nilai ke sebuah variabel. Jangan sampai tertukar ya..'''

'''Anda telah belajar tentang boolean kan dengan nilainya yang True atau False.

Coba lihat code di samping, apakah anda bisa menebak nilai dari setiap perbandingan sebelum anda menjalankan codenya?'''