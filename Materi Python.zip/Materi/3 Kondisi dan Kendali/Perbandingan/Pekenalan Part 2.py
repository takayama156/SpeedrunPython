# 400 < 100
perbandingan_satu = False

# 10 * 2 == 20
perbandingan_dua = True

# 50 > 10
perbandingan_tiga = True

# 50 * 2 != 100
perbandingan_empat = False

# 2 * 3 * 4 >= 24
perbandingan_lima = True

# "Python" == "PHP"
perbandingan_enam = False

'''Unit sebelumnya sudah dikenalkan dengan operator perbandingan. Sekarang mari kita berlatihnya.'''

'''Lihat code di samping. Kita punya perbandingan_satu hingga perbandingan_enam. Dua variabel pertama telah kita kerjakan, sisanya anda yang lanjutkan. Caranya cukup lihat perbandingan di komentar tepat di atas variabelnya, dan tebak apa hasil dari perbandingan itu. Cukup berikan nilai True jika anda rasa perbandingannya benar, dan berikan nilai False jika anda rasa perbandingannya salah.'''