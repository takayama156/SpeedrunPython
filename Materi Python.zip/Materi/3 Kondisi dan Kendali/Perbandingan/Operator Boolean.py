print(False and True)
print(True and False)

print(False or True)
print(True or False)

print(not True)

'''Sebelumnya kita pernah belajar tentang operator matematika, sekarang kita belajar tentang operator boolean. Ada dua jenis operator boolean, jenis pertama adalah operator yang menerima dua pernyataan. Mereka adalah:

and yang akan mengeluarkan nilai True jika kedua pernyataan bernilai True.
or yang akan mengeluarkan nilai True jika salah satu saja dari dua pertanyaan bernilai True.
Jenis operator lain adalah operator yang hanya menerima satu pertanyaan, yaitu:

not yang akan mengeluarkan nilai berlawanan dari pernyataan yang diberikan.
Apa maksudnya pernyataan di sini? Pertanyaan itu seperti perbandingan yang kita buat sebelumnya atau segala sesuatu yang menghasilkan nilai True atau False.'''

'''Jika anda tidak terlalu mengerti penjelasan di atas, tidak apa. Mari coba mengerti dari contoh!

Coba jalankan code di samping kanan dan lihat outputnya! Apakah anda mengerti kenapa ada yang True dan ada yang False? Coba ubah-ubah True menjadi False di editor. Atau ubah and menjadi or. Lalu jalankan lagi dan perhatikan outputnya! Terserah anda! Yang penting anda harus rajin ngulik-ngulik untuk menjadi coder nomer wahid!'''