# (5 > 10) and (10 > 5)
satu = False

# (5 >= 1) and ( 5 <= 12)
dua = True

# ( 5 * 2 == 10 ) and ( 10 > 3 * 3 )
tiga = True

# ( 3 ** 2 > 8 ) or ( 100 <= 99 )
empat = True

# ( 4 + 4 > 8 ) or ( "Python" == "JavaScript" )
lima = False

# not (100 * 10 >= 100 )
enam = False

'''Di unit sebelumnya anda pasti masih ingat bahwa 2 > 1 itu menghasilkan True. Yup, anda bisa langsung menggunakan perbandingan seperti 2 > 1 ke operator boolean. Contohnya:

satu = (2 > 1) and (2 > 0)
dua = (2 > 1) or (2 < 0)
tiga = not (2 > 1)
Nantinya satu dan dua akan bernilai True, sedangkan tiga akan bernilai False. Tanda kurung ( ) di atas sebenarnya tidak wajib, tapi dengan adanya tanda kurung kita lebih mudah membacanya.

Nantinya kita bisa mengambil keputusan dari banyak perbandingan yang harus dipikirkan, contoh sederhananya:'''

'''beli = harga < 1000 and kualitas > 8
Jadi jika harga dibawah 1000 dan kualitas-nya di atas 8 maka beli akan bernilai True! Kerenkan? Jadi jangan menyerah untuk belajar, mungkin operator boolean ini belum terlihat berguna sekarang, tapi nantinya akan sangat berguna.'''

'''Di samping kita punya satu hingga enam. Untuk satu sudah kita kerjakan. 

# (5 > 10) and (10 > 5)
satu = False
satu bernilai False karena walaupun 10 > 5 adalah True, tetapi 5 > 10 adalah False dan operator and membutuhkan kedua pernyataannya True agar nilai akhirnya menjadi True.

Seperti satu, untuk berikutnya anda kerjakan dengan menebak apa hasilnya jika komentar di atas nama variabelnya dijalankan. '''

'''Apakah terlihat ribet? Memang ribet! Hahaha... Tapi program umumnya mempertimbangkan banyak variabel dan perbandingan yang diperiksa sebelum memberikan keputusan. Apakah anda pikir saat CodeSaya memeriksa jawaban anda hanya satu atau dua saja perbandingan yang dilakukan? ^^'''