angka = 5

if angka > 2:
  print("if, nilai angka sekarang: " + str(angka))

while angka > 2:
  print("while, nilai angka sekarang: " + str(angka))
  angka = angka - 2
  
'''Pengulangan while mirip dengan sebuah if: mengeksekusi code di dalamnya jika kondisi yang diberikan bernilai True. Perbedaannya adalah di while code di dalamnya akan terus berulang terus selama kondisinya benar.

Sintaksnya pun mirip dengan if seperti berikut:

while suatu_kondisi:
  # lakukan sesuatu
Agar codenya tidak berjalan terus menerus (inifinite loop), harus ada code di dalam loop yang membuat suatu_kondisi menjadi False.'''

'''Jalankan code di samping, perhatikan perbedaan outputnya if dan while.
Sekarang ubah angka menjadi 5. Perhatikan lagi outputnya.
angka = angka - 1 adalah cara kita untuk membuat angka > 2 bisa menjadi False suatu saat. Jika anda menghapus garis ini maka akan terjadi masalah besar karena angka > 2 akan menjadi selalu True! Tapi anda bisa mencoba untuk mengubahnya menjadi angka = angka - 2.'''