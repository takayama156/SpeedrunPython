angka = 0

while True:
  print(angka)
  angka = angka + 1
  if angka >= 5:
     break


'''Code break di dalam loop artinya adalah "keluar dari loop ini". Ini adalah sebuah cara untuk keluar dari sebuah loop selain kondisi yang telah ditentukan di while. Contohnya seperti ini:

while True:
  # lakukan sesuatu
  print "Lanjutkan loop?"
  lanjut = False
  if not lanjut:
    break
Di contoh atas kita membuat sebuah infinite loop dengan membuat kondisi di loop selalu True. Akan tetapi di dalam loop kita membuat jika lanjut sama dengan False maka break akan dijalankan sehingga pada akhirnya loop ini akan berakhir. Ingat kembali bahwa nilai dari not False itu adalah True.

break digunakan jika anda tidak mengetahui pasti kapan loop akan berhenti. Misalnya pada contoh di atas kita bisa mendapatkan nilai lanjut dari user, database, ataupun faktor eksternal lainnya.

Perbedaan lainnya dengan menggunakan break, code di atas pasti akan dijalankan minimal satu kali.'''


'''Anda pasti sudah susah payah dalam mengerjakan soal di unit sebelumnya? Untuk kali ini mudah, cukup berikan break di tempat yang tepat di code samping agar tidak error.'''