from random import randint

hitung_kepala = 0
hitung_total = 2

while True:
  
  # angka integer acak: 0 atau 1
  putar  = randint(0,1)
  
  if putar:
    hitung_kepala  = hitung_kepala + 1
    print(str(hitung_total) + " kepala " + str(hitung_kepala))
  else:
    hitung_kepala = 0
    print(str(hitung_total) + " buntut")
    
  hitung_total = hitung_total + 1

  if not (hitung_kepala < 3 and hitung_total < 100):
    break

print("Muncul kepala " + str(hitung_kepala) + " kali berturut-turut.")

'''Kali ini kita akan menggunakan sebuah module bernama random yang memiliki function bernama randint. Function randint berguna memberikan angka integer secara acak.

 Instruksi:
Anggap kita memilki sebuah koin yang mengeluarkan kepala (angka 1) atau ekor (angka 0). Loop akan terus berputar hingga koin mengeluarkan kepala tiga kali berturut-turut.

Pelajari code di samping, jalankan berkali-kali dan lihatlah outputnya yang berubah-ubah.

Tidak perlu lakukan apapun (kecuali jika anda ingin mengulik-ulik code di samping), dan selamat anda sudah belajar sejauh ini! Terus lanjutkan sampai dapat lencana Python dari CodeSaya!'''