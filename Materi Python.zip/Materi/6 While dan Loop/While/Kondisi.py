angka = 0

while angka <= 100:
  print(angka)
  angka = angka + 3
  
'''Kondisi di while menentukan apakah loop akan dijalankan atau tidak. Dari code di unit sebelumnya kita punya:

angka = 5

while angka > 2:
  print angka
  angka = angka - 1
Di contoh ini, saat bertemu dengan while pertama-tama Python akan bergumam "Hm, okay saya akan jalankan code setelah tanda : jika angka memang lebih besar daripada 2. Oh angka nilainya 5, baiklah jalankan code. Sudah selesai? Oke sekarang angka nilainya berapa? 4? 4 masih lebih besar dibandingkan 2 baiklah jalankan lagi!" sampai pada suatu saat "Hah? sekarang angka nilainya 2? 2 tidak lebih besar daripada 2! tetapi sama! Baik jangan jalankan code ini lagi. Jalankan code berikutnya!"

Kurang lebih mungkin seperti itu. XD'''

'''Soal ini akan sedikit menggelitik indera matematika anda. 

Tugas anda sederhana saja, dengan while, cetak setiap angka dari 0 hingga 100 tetapi hanya angka yang merupakan kelipatan 3.'''

'''Apakah anda tahu jika anda ingin membuat software game anda harus pintar matematika? Benar sekali jadi jika anda ingin jadi pembuat game dan anda masih di sekolah, rajin-rajinlah belajar matematika.

Untuk mencetak angka dari 10 hingga 0 tetapi hanya angka yang kelipatan 2 salah satu caranya seperti ini:

angka = 10

while angka >= 0:
  print angka
  angka = angka - 2'''