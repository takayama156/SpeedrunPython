angka1 = 6
string = ""

while angka1 >= 1: 
  angka2 = angka1
  
  while angka2 > 0:
    string = string + "*"
    angka2 = angka2 - 1
    
  string = string + "\n"
  angka1 = angka1 - 1 
  
print(string)

'''While bisa dibuat bertingkat loh, seperti ini:

while kondisi_1:
  while kondisi_2:
    # lakukan sesuatu
  # lakukan yg lain
Perhatikan spasi untuk code di atas, while pertama memiliki blok code baris ke 2 dan baris ke 4. sementara while ke 2 memiliki blok code di baris ke 3.

 Instruksi:
Perhatikan code di samping dan jalankan. Anda akan melihat bahwa outputnya seperti ini:

*
**
***
****
*****
Sekarang ubah code di samping sehingga outpunya terbalik menjadi seperti ini:

*****
****
***
**
*
Jika anda kesulitan lihat petunjuk di bawah, ada informasi baris mana saja yang harus diubah. '''

'''Tekan tombol ulangi dan ubah di baris ke 1, 4 dan 12. Di baris ke 1 ubah angka 1 menjadi angka lain yang lebih besar. Di baris ke 4 ubah <= 5 menjadi > 0.  Di baris ke 12 ubah operator matematikanya ;).

Apakah anda bisa bentuk yang lainnya? seperti ini misalnya:

    *
   ***
  *****
 *******
*********
Jika ya, sombongkan code anda di forum!'''