print("Berhitung..")

for i in range(10):
    print(i)

print("Boom..!!")

'''Selain while, kita bisa menggunakan for untuk melakukan pengulangan. Sebelumnya kita pernah singgung tentang for di unit tentang list. Untuk menyegarkan ingatan anda, mari kita lihat sintaksnya yang seperti ini:

for item in nama_list:
  # lakukan sesuatu, misalnya
  print item
Anda pun ingat tentang range() di unit sebelumnya kan? Sebagai pengingat, range() itu contohnya seperti ini:

a = range(4)
b = [0, 1, 2, 3]
print a == b # menghasilkan True'''

'''Buatlah pengulangan untuk berhitung dari 0 hingga 9.'''