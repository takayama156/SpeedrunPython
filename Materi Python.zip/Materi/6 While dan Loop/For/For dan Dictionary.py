orang = { 'nama' : 'Linus Torvalds',
  'tahun lahir': 1969,
  'warga negara': 'Finlandia' }

for kunci in orang:
  print("{}: {}".format(kunci, orang[kunci]))
  
framework = { 'nama' : 'Django',
  'bahasa': "Python",
  'tahun lahir': 2005,
  'versi': '1.9.6' }

for test in framework:
  print("{}: {}".format(test, framework[test]))
  
'''For dan Dictionary
Tidak hanya list yang bisa menggunakan for tetapi juga dictionary. Caranya bisa anda lihat di code samping.'''

'''Kita telah mencetak orang, sekarang bagian anda untuk mencetak framework menggunakan format pencetakan yang sama.'''