# anda sudah bisa menggunakan for dengan range()
for i in range(1000, 1, -200):
  print(i)

# sudah bisa juga untuk mencetak sebuah list
for p in [ 2, 3, 5, 7 ]:
  print(p)

# termasuk mencetak string
for s in "string":
  print(s)

# dictionary juga
dict = { 'nama' : 'saya', 'umur': 17 }
for d in dict:
  print(d + ": " + str(dict[d]))
  
'''Mari kita ulas apa yang telah anda pelajari!'''
