for i in range(99,5,-3):
  print(i)
  
'''Apakah anda masih ingat tentang range() yang dapat menerima tiga parameter seperti ini:

range(10,30,5)
Yang akan mengeluarkan output [10, 15, 20, 25]. Gunakan konsep ini dalam mengerjakan soal di unit ini.'''

'''Mari kita berhitung mundur! Cetak angka 99 hingga 6 dengan angka kelipatan 3 seperti ini:

99
96
93
..
(terus sampe bawah)
..
12
9
6'''

'''Parameter pertama bisa dibuat lebih besar dibandingkan parameter kedua selama parameter ke tiga di range() diberikan nilai negatif.'''