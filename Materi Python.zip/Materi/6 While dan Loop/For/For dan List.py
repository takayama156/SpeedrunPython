kelas = ["Python", "PHP", "JavaScript", "Git"]

for i in kelas:
  print(i)
  
'''Kali ini kita akan mencetak sebuah list.'''

'''Cetak semua isi di dalam list kelas dengan for.'''