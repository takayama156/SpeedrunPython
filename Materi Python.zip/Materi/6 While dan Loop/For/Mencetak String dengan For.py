# teks dibawah diambil dari https://id.wikipedia.org/wiki/Python_(bahasa_pemrograman)

kalimat = "Python adalah bahasa pemrograman yang berfokus pada keterbacaan kode."

for k in kalimat:
  print(k)


'''Sebelumnya kita pernah menyinggung bahwa string sebenarnya mirip sekali dengan list. Benar, bahkan kita bisa menggunakan for untuk mencetak setiap karakter satu per satu di sebuah string selayaknya sebuah list. Seperti ini:

kata = "Hebat"
for k in kata:
  print k
yang akan mencetak:

H
e
b
a
t'''

'''Cetak satu persatu karakter yang ada di kalimat dengan menggunakan for seperti contoh di atas.'''

'''Hm, kita tidak tahu di kehidupan nyata apa gunanya mencetak karakter satu persatu dari sebuah string. Tapi ini good to know lah. XD'''