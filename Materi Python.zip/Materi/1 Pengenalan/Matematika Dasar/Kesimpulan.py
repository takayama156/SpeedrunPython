#ini script testku

jumlah_pacar = 70
lagi_galau = True
pengurangan = 7-29

''''Selamat anda sudah sampai pada unit ini! Bagaimana pendapat anda tentang Python? Mudah kan!? Jangan salah, walaupun mudah bukan berarti Python itu lemah! Dengan python anda bisa buat apa saja! Mari kita ulas apa saja yang telah kita pelajari:

Variabel: untuk menyimpan data,
Tipe data: boolean dan angka,
Spasi: pentingnya spasi di python,
Komentar: untuk menjelaskan code,
Operasi matematika: mulai dari penambahan sampai modulus!'''

'''Buatlah komentar di garis pertama,
Buat variabel bernama jumlah_pacar yang isinya angka (bukan desimal),
Buat variabel bernama lagi_galau yang isinya boolean,
Buat variabel dengan nama terserah anda dan gunakan salah satu dari operator matematika yang telah kita pelajari.
'''