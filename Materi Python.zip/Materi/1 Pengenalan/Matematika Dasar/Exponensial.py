angka = 4 ** 2
print(angka)

'''Semua perhitungan itu bisa anda lakukan di kalkulator, lalu kenapa menggunakan Python? Karena kita bisa menggabungkannya dengan tipe data (boolean misalnya) yang lain dan membuat program yang berguna. Sementara calculator hanya bisa berhitung. Sekarang mari kita belajar tentang exponensial (perpangkatan), contohnya begini:

delapan = 2 ** 3
Di contoh atas, kita membuat variabel bernama delapan dan mempunyai nilai 8 karena itu adalah hasil dari 2 pangkat 3.

Perhatikan bahwa kita menggunakan ** dan bukan * untuk melakukan perpangkatan.'''

'''Buatlah sebuah variabel bernama angka yang sama dengan 4 pangkat 2 di baris pertama.'''