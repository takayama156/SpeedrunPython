pengurangan = 30 - 15

penambahan = 10 + 20

pembagian = 20 / 4

perkalian = 10 * 5


print(perkalian)

'''Mari kita lakukan matematika sekarang. Anda bisa menambah, mengurangi, perkalian, dan pembagian seperti ini:

penambahan = 100 + 200

pengurangan = 200 - 100

perkalian = 3 * 7

pembagian = 100 / 25'''

'''Ganti tanda ? dengan tanda matematika yang sesuai dengan nama variabelnya.
Jangan ubah angka sama sekali.'''