total_umur_dalam_hari = 75
jumlah_hari_dalam_sebulan = 30

bulan = total_umur_dalam_hari / jumlah_hari_dalam_sebulan

hari = total_umur_dalam_hari % jumlah_hari_dalam_sebulan

print("Umur bayi itu sekarang " + str(bulan) + " bulan dan " + str(hari) + " hari.")