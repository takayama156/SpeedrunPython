"""ini 
jadi komenter"""

print("hello")

'''Tanda baca # hanya akan menuliskan komentar sebuah baris saja. Jika kamu ingin menuliskan komentar lebih dari satu baris, memulai setiap barisnya dengan tanda # akan melelahkan.

Sehingga untuk menuliskan komentar yang lebih dari satu baris, anda bisa memulainya dengan tanda kutip tiga kali secara berurutan dan mengakhirinya lagi dengan tanda yang sama, seperti ini:''''

'''""" Ini jadi komentar
ini juga komentar loh
dan berakhir disini'''