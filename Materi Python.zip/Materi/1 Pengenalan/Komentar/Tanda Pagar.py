#
jumlah_semuanya = 192039000

print(jumlah_semuanya)

'''Mungkin anda sudah melihat kita menggunakan tanda # beberapa kali di latihan sebelumnya. Tanda # digunakan untuk memberikan komentar. Sebuah komentar adalah sebuah text yang tidak akan dijalankan oleh Python sebagai code. Komentar hanya dapat dibaca oleh manusia.

Komentar digunakan untuk membuat program kamu agar lebih mudah dimengerti. Ketika kamu melihat code kamu lagi suatu saat nanti, kamu tidak akan kesulitan untuk mengerti apa maksud dari code kamu.

Komentar juga sangat berguna jika anda bekerja di sebuah tim, dengan adanya komentar, teman kerja anda akan lebih mudah untuk mengerti maksud dari program bikinan anda. Seorang coder yang mampu bekerja dalam tim sangatlah dihargai.'''

'''Tulislah komentar di baris pertama dengan menggunakan #.

Setelahnya jalan code di samping tanpa merubah apapun.'''

'''Komentar anda bisa jadi terlihat seperti ini:

# Variabel ini didapat dari
# menjumlahkan semua hutang
# yang saya puny'''