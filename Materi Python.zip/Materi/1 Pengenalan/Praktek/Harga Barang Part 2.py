harga_laptop = 7000000
uang_muka = 1000000

sisa_cicilan = 7000000 - 1000000

print(sisa_cicilan)

'''Sekarang kita hitung berapa sisa cicilannya menggunakan salah satu operator matematika yang telah kita pelajari sebelumnya!'''

'''Di baris ke 4, buat variabel sisa_cicilan yang merupakan hasil dari mengurangi harga_laptop dengan uang_muka.'''