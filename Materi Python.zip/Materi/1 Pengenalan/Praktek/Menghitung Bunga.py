harga_laptop = 7000000
uang_muka = 1000000

sisa_cicilan = harga_laptop - uang_muka
suku_bunga = 5
jumlah_bunga = sisa_cicilan * suku_bunga / 100

print(jumlah_bunga)

'''Sekarang kita menghitung bunganya! Oh ya, apakah anda tahu bahwa kita bisa me-'rantai' perhitungan seperti ini:

jawaban = 2000 * 4 / 100
kita sekarang akan membuat hal serupa di sini!'''

'''Ciptakan variabel suku_bunga dan berikan nilai antara 5 hingga 30.
Ciptakan juga variabel jumlah_bunga yang merupakan hasil perkalian sisa_cicilan dan suku_bunga dan dibagi 100. Kenapa dibagi 100? karena suku_bunga satuannya adalah persen.'''