harga_laptop = 5000001
uang_muka = 1000000

'''Mari kita praktekan ilmu yang telah kita pelajari sebelumnya!

Misalnya kita akan membeli laptop dengan sistem kredit dibayar setahun.'''

'''Buat sebuah variabel yang bernama harga_laptop, dan berikan harga berapapun lebih dari 5000000.
Buat juga uang_muka, dan berikan angka berapapun kurang dari 2000000.'''

'''Di coding, untuk menuliskan tiga juta itu seperti ini 3000000 bukan 3.000.000.'''