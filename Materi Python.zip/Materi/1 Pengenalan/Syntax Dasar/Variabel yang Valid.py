Nama_Bahasa = "python"

P3MBU4T = "Guido van Rossum" # nama variabel yang 'alay', tapi apakah valid?

Tahun_Dibuatnya = 1991

# variabel panjang nih
contoh_perusahaan_yang_menggunakan_bahasa_python = "Youtube, Path, CodeSaya, dan lain-lain."

Belajar_Python_Di_Codesaya = True

Emang_Seru= "Benar"

'''Syarat variabel yang valid di python:

Nama variabel panjangnya minimal 1 huruf,
Menggunakan huruf (besar atau kecil), underscore _, atau angka 0 hingga 9,
Case sensitif, artinya variabel SAYA dan saya itu berbeda,
Variabel tidak boleh dimulai dari angka.
Variabel boleh dimulai dari underscore _, tetapi di Codesaya dilarang untuk keamanan.'''
