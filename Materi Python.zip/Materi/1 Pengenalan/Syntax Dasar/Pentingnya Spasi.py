komputer = 1
laptop = 2

'''Di Python, spasi sangatlah penting karena itu anda harus berhati-hati dalam menggunakannya. Karena spasi digunakan untuk menstruktur code. Apa itu menstruktur code? Akan kita jelaskan nanti, tapi untuk saat ini kita akan mendemonstrasikan pentingnya spasi di Python.'''


'''IndentationError: expected an
indented block 
(<string>, line 2)
Error tersebut karena ada kesalahan dalam strukturnya, betulkan dengan menghapus spasi sebelum laptop = 2. Buat sejajar dengan baris pertama.''''

'''Karena menekankan penggunaan spasi dibandingkan tanda baca seperti ; ( ) { } $ @, code di python lebih mudah dibaca dibandingkan bahasa lain.'''