laptop = 2

'''Menciptakan program membutuhkan kemampuan untuk menyimpan data. Untuk melakukannya kita menggunakan variabel. Contohnya:

desktop = 5

Dengan baris code di atas, sekarang kita punya sebuah variabel yang bernama desktop dan memiliki nilai 5.'''

'''Ciptakan variabel yang bernama laptop dan beri nilai 2.
Tekan "Periksa & Simpan" untuk menjalankan code anda.'''