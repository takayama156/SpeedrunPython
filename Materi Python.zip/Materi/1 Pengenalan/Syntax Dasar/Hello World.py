print("Hello Dunia")

'''Python adalah sebuah bahasa pemograman yang mudah untuk dipelajari. Dengan python, anda bisa membuat aplikasi web, aplikasi desktop, games, AI, dan lain-lain.'''

'''Hint: Jangan salah menuliskan Python dengan Phyton.
Cara membaca Python adalah "paiton" bukan "piton".
Selain menekan tombol "► Periksa", anda pun bisa menekan Ctrl dan Enter secara bersamaan untuk menjalankan code anda.'''