angka_saya = 1945
float_saya = 17.8
boolean_saya = True

'''Selamat! Anda baru saja menyimpan sebuah angka di variabel laptop. Angka adalah salah satu tipe data di coding. Tipe data lainnya yang akan kita pelajari kali ini adalah boolean.

Boolean dapat diibaratkan sebagai sebuah lampu. Seperti halnya lampu yang hanya memiliki dua nilai (hidup atau mati), boolean juga hanya memiliki dua nilai, yaitu True atau False. Kita bisa menggunakan variabel untuk menyimpan nilai boolean seperti ini:

berjuang = True

menyerah = False'''

'''Buat variabel-variabel berikut dan definisikan sesuai nilai yang diminta:

angka_saya memiliki nilai 1945
float_saya diisi dengan desimal 17.8 
boolean_saya menjadi True'''

'''perhatikan bahwa huruf pertama di True dan False adalah huruf kapital!

Buat variabel di setiap baris yang berbeda!'''