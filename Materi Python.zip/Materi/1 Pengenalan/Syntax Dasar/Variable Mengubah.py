# angka_saya telah kita beri nilai 1945

angka_saya = 1945

# setelah didefinisikan dan diberi nilai
# kita bisa mengubah nilainya

angka_saya = 1

# Untuk melihat kalau kita telah mengubahnya,
# kita akan mencetaknya dengan print
# print akan dijelaskan di pelajaran berikutnya

print(angka_saya)

'''Sekarang anda tahu bagaimana caranya untuk menyimpan nilai di variabel.

Misalnya kita sudah punya angka_saya = 1945. Kita bisa merubah nilainya seperti ini:

angka_saya = 1'''

'''Ubah nilai dari angka_saya dari 1945 menjadi 1'''