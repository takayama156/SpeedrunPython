from math import floor, ceil

print(floor(3.14))
print(ceil(3.14))

'''Impor yang telah kita lakukan sebelumnya disebut dengan impor fungsi. Polanya seperti ini:

from nama_modul import nama_fungsi
jika ada lebih dari satu buah fungsi di modul yang sama yang ingin kita impor, kita gunakan tanda , seperti ini:

from modul import fungsi_1, fungsi_2
Sekarang kita akan mencoba untuk mengimpor modul matematika bernama math. di modul math ada beberapa function contohnya sin, cos, log, pow dan lain sebagainya. Anda bisa mengimpornya selayaknya anda mengimpor diskon() dari module codesaya di unit sebelumnya. '''

'''Di baris pertama, dari module bernama math, mari kita impor dua buah fungsi yaitu floor() dan ceil().
Jalankan dan lihat outputnya. Apakah anda bisa menebak apa gunanya floor() dan ceil()? Diskusikan di forum jika anda tidak mengerti.'''