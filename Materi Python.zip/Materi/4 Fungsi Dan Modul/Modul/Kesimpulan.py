# Anda sudah bisa mengimpor fungsi yang anda buat

# Anda juga bisa mengimpor fungsi lebih dari satu

from math import log10, factorial

print(log10(100))
print(factorial(4))

# Anda juga bisa mengimpor fungsi secara generik

import math

print(math.pow(5, 2))
print(math.sqrt(25))

'''Di sini kita akan mengulas apa yang telah kita pelajari, tetapi ulasannya ada di editor!'''

'''Lihat code di samping, baca juga komentarnya, resapilah! Jika anda masih bingung, lihat unit yang membahas tentang itu. Jika masih bingung, silahkan diskusikan di forum.'''