import math

print(math.floor(3.14))
print(math.ceil(3.14))

'''Selain impor secara function, kita pun bisa impor modul secara generik. Syntaksnya seperti ini:

import nama_module
Nantinya, function di nama_module bisa dipanggil dengan cara seperti ini:

nama_module.nama_fungsi()
Untuk contoh modul codesaya, kita bisa melakukannya seperti ini:

import codesaya
print codesaya.diskon(100)'''

'''Kita punya dari unit sebelumnya code yang mengimpor secara fungsi. Ubah cara impornya ke impor generik.
Karena kita mengimpornya secara generik, pemanggilan fungsi floor() dan ceil() nya pun berubah. Perbaikilah!'''