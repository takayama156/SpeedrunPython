from codesaya import diskon

print(diskon(400))
print(diskon(200))

'''Caranya mengimpor modul atau library sudah tidak asing buat kita. Di sub bab sebelumnya tentang datetime kita sudah melakukan seperti ini:

from datetime import datetime
Sekarang kita akan mengimpor fungsi diskon() yang kita telah buat di sub-bab sebelumnya. Kita simpan diskon() di sebuah file bernama codesaya.py di folder yang sama dengan script.py yang berada di samping kanan. Cara mengimpornya cukup seperti ini:

from codesaya import diskon
mudah kan? Nantinya diskon() akan langsung bisa anda gunakan. '''

'''Impor fungsi diskon() dari codesaya.
Cetak dengan print fungsi diskon() dengan parameter bernilai 400.
Sekali lagi dibawahnya cetak print untuk diskon() dengan parameter bernilai 200.'''

''' mencetaknya fungsinya cukup seperti ini:

print diskon(100)
Tunggu dulu, apakah ini artinya ada file bernama datetime.py di folder yang sama dengan script.py? Untuk kasus ini tidak. Pertama Python akan memeriksa apakah ada datetime.py di folder yang sama dengan script.py, jika tidak ada maka Python akan memeriksanya di folder khusus yang telah ditentukan oleh python.'''