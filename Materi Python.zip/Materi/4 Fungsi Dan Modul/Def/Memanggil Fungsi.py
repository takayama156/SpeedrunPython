def merayu(nama):
  """ Gunanya untuk merayu """
  print("Aku suka " + str(nama))

def pelajar():
  """ Menjelaskan hobi pelajar """
  print("Aku rajin belajar!")

# panggil merayu di sini
merayu("CodeSaya")

# panggil pelajar di sini
pelajar()

'''Di sebelumnya anda sudah membuat sebuah fungsi, tapi bagaimana cara menggunakannya? Seperti ini:

nama_function("parameternya")

nama_function_lain()
Di contoh atas, di baris pertama kita menggunakan/memanggil fungsi nama_function() dan memberikan "parameternya" sebagai parameternya di dalam tanda kurung. Di baris berikutnya, kita menggunakan nama_function_lain() yang kali ini tidak memiliki parameter.

Cara menggunakannya sama dengan anda dahulu saat menggunakan fungsi len() maupun str() di unit sebelumnya. Mudah kan?

Ingat, jangan gunakan def sebelum nama fungsi saat memanggil fungsi tersebut. def hanya digunakan saat membuat sebuah fungsi.'''

'''Kita sekarang punya dua buah fungsi yaitu: merayu() dan pelajar().
Di baris ke 10, panggil fungsi merayu() dan masukkan "CodeSaya" sebagai parameternya.
Di baris ke 13, panggil fungsi pelajar() tidak perlu masukkan parameter apapun karena memang telah di-def-inisikan tidak ada parameternya.'''