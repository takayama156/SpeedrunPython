def diskon(harga):
  if harga > 300:
    return harga / 10
  elif harga > 100:
    return harga / 20
  else:
    return 0
    
'''Di sub bab ini anda telah belajar banyak tentang fungsi:

Manfaatnya fungsi yaitu untuk mengurangi menulis code yang berulang-ulang,
Komponen-komponen di fungsi yaitu: header, komentar, dan blok code,
Cara memanggil/menggunakan fungsi,
Bagaimana membuat fungsi me-return sebuah nilai,
Cara membuat fungsi dengan multi parameter,
Membuat fungsi memanggil fungsi lain.
Satu lagi, mari kita lihat contoh berikut:

def ketawa(lucu):
  if lucu > 8:
    return "Hahaha"
  elif lucu > 4:
    return "Ha"
  else:
    return "Garing!"
Apaan ini? Kenapa ada banyak sekali return? Yup, anda bisa gunakan return lebih dari satu di sebuah function. Tetapi tetap saja, setelah code menemukan return, maka code akan selesai menjalankan function itu.'''

'''Mari kita buat sebuah function yang bernama diskon() yang menerima sebuah parameter bernama harga.
Jika harga di atas 300, maka diskon() akan mengembalikan nilai harga dibagi dengan 10,
Jika harga di antara 100 hingga 300, maka diskon() akan mengembalikan nilai harga dibagi dengan 20,
Jika harga di bawah 100, maka diskon() akan mengembalikan 0'''

'''Code anda akan mirip dengan ini:

def d(h):
  if h > 3:
    return h / 10
  elif h > 1:
    return h / 20
  else:
    return 0'''