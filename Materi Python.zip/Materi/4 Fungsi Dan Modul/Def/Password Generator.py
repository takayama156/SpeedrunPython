# buat function di sini
def pembuat_password(website, tahun):
    return website.lower() + str(tahun*11)

# kita lihat hasil dari function anda di sini
print(pembuat_password("CodeSaya.com", 2016))

'''Ada dua hal yang anda akan pelajari kali ini, yang pertama adalah menggunakan lebih dari satu parameter. Dan memanggil function lain di function anda sendiri, contohnya seperti ini:

def iseng(kata, angka):
  return kata.upper() + str(angka*2)
wow = iseng("seru", 21)
Apakah anda bisa menebak nilai dari wow? Tepuk pundak anda jika anda menjawab "SERU42". Ya, untuk menggunakan dua parameter cukup membatasinya dengan koma , seperti ini:

(param1, param2, param3, param4)
Di function yang anda buat, anda bisa memanggil function seperti str(), len() atau bahkan function yang telah anda buat sebelumnya.'''

'''Buat sebuah function bernama pembuat_password()
function ini menerima dua buat parameter yaitu website, dan tahun.
Mirip seperti iseng(), tetapi alih-alih menggunakan upper(), kita menggunakan lower() di website. Dan alih-alih mengalikan angka dengan 2, kita mengalikan tahun dengan 11.'''