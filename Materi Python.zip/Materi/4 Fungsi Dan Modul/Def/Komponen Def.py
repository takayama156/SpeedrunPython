def merayu(nama):
  """Amogus"""
  print("Aku suka " + str(nama))
  
'''Fungsi didefinisikan dengan tiga komponen:

header, yang memiliki kata kunci def, nama fungsi, parameter functionnya, dan juga tanda titik dua :.
def hello(nama):
komentar, yang menjelaskan apa yang fungsi ini lakukan. Ini opsional.
""" Gunanya untuk menyapa """
blok code, yang merupakan code yang akan dijalankan oleh function. Perhatikan indentasinya.
print "Hello " + str(nama)
Secara bersamaan, mereka menjadi seperti ini:

def hello(nama):
  """ Gunanya untuk menyapa """
  print "Hello " + str(nama)
Untuk code di atas, nama functionnya adalah hello. Memiliki satu parameter yaitu nama. Memiliki komentar untuk menjelaskan apa fungsi dari hello(). Dan akhirnya memiliki satu buah baris di blok code-nya.'''

'''Sekarang buatlah sebuah function bernama merayu yang memiliki satu parameter yaitu nama.
Terserah anda untuk menggunakan komentar atau tidak.
Lalu di blok code nya anda buat untuk mencetak "Aku suka " + str(nama).'''