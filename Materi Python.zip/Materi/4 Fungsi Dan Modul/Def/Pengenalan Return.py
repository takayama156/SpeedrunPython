# buat function pangkat_dua()
def pangkat_dua(angka) :
  return angka ** 2

naga = pangkat_dua(5)

'''Di unit sebelumnya fungsi yang kita buat langsung mencetak sebuah kalimat. Tapi seringnya kita tak ingin function untuk mencetak kalimat, umumnya kita ingin function untuk memberikan sebuah angka, string, atau yang lainnya. Masih ingat dengan len()? Benar, fungsi itu memberikan kita sebuah angka yang merupakan panjang string yang kita berikan ke len(). Lalu bagaimana caranya agar function kita melakukan hal seperti itu? Kita menggunakan return, contohnya seperti ini:

def merayu(nama):
  return "Aku suka " + str(nama)
Setelah keyword return, anda bisa berikan apa saja yang anda ingin function ini kembalikan. Di contoh atas kita membuat merayu() agar mengembalikan sebuah string yang dipengaruhi oleh parameter nama yang diberikan. Nantinya kita bisa menggunakan merayu() seperti ini:

kata = merayu("Python")
Nantinya kata akan memiliki nilai "Aku suka Python". Atau kita bisa menggunakan merayu() seperti ini:

print merayu("coding")
Yang akan langsung mencetak "Aku suka coding".'''

'''Buat function bernama pangkat_dua() menerima satu buah parameter bernama angka,
pangkat_dua() mengembalikan (me-return) pangkat dua dari angka yang diberikan,
Di baris ke 5, panggil pangkat_dua(5) dan simpan di variabel yang bernama naga. Pastikan anda tidak memberikan spasi (indentasi) di baris ini karena baris ini bukan lagi bagian dari fungsi pangkat_dua().'''

'''Untuk mendapatkan pangkat dua dari sebuah variabel, anda bisa melakukan ini:

angka * angka

atau

angka ** 2'''