# def gunanya untuk membuat suatu function
# untuk code yang masuk ke dalam function diberikan spasi yang seragam

def hitung_tagihan(uang_muka):
  harga_laptop = 7000
  sisa_cicilan = harga_laptop - uang_muka
  suku_bunga = 10 # dalam persen
  jumlah_bunga = sisa_cicilan * suku_bunga / 100
  total_tagihan = sisa_cicilan + jumlah_bunga
  tagihan_bulanan = total_tagihan / 12
  return tagihan_bulanan
  
print(hitung_tagihan(1000))

print(hitung_tagihan(2000))

'''Sangat mungkin sekali di sebuah pemograman kita membutuhkan untuk menggunakan code yang sama tetapi dengan beberapa nilai yang berbeda. Daripada kita menulis ulang keseluruhan codenya, akan lebih cerdas jika kita membuat fungsi/function kita sendiri. Nantinya fungsi ini dapat kita gunakan lebih dari satu kali.'''

'''Silahkan intip code di samping. Anda mungkin masih ingat dengan pelajaran di bab pertama tentang menghitung tagihan bulanan. Nah, code di samping mengambil contoh dari unit itu dan mengubahnya ke bentuk function. 

Lihat seberapa banyak anda mengerti tentang code di samping. Ketika kamu sudah selesai membacanya, tekan Periksa dan Simpan. Perhatikan outputnya dan lanjutkan ke unit berikutnya.'''