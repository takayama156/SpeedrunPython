# saat inputnya satu, range(X)
# artinya dari 0 hingga X
printk(range(10))

# saat inputnya dua, range(X, Y)
# artinya dari X hingga Y
print(range(1, 10))
print(range(8, 10))

# saat inputnya tiga, range(X, Y, Z)
# artinya dari X hingga Y dengan penambahan sebanyak Z
print(range(1, 10, 2))
print(range(1, 10, 5))

'''range() adalah sebuah fungsi serbaguna yang gunanya untuk menciptakan sebuah list yang terdiri dari angka. Apa itu list? Ada di bab selanjutnya, sekarang mari kita fokus ke range() terlebih dahulu.'''

'''Instruksi:
Tidak ada instruksi, cukup jalankan saja code di samping. 
Ubah angka di dalam range() jika anda ingin melihat apa yang terjadi saat anda mengubah angkanya.'''

'''Parameter di range() bisa terdiri dari satu hingga tiga parameter. Dan perilaku dari range() berubah sesuai dengan jumlah parameter yang anda berikan.'''