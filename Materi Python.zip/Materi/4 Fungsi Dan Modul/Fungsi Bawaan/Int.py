pi = 3.14

pi_bulat = int(pi)

print(pi)
print(pi_bulat)

'''Sekarang anda telah mengerti apa itu fungsi dan bagaimana cara mengimpor fungsi dan modul. Untuk sub-bab ini, kita akan menggunakan function yang telah ada di Python secara otomatis.

Anda sudah tahu tentang str() yang mengubah sebuah non-string menjadi string. Sekarang kita punya int() yang mengubah sebuah non-angka bulat menjadi angka bulat. int adalah kepanjangan dari integer yang artinya adalah angka bulat di programming. Anda pasti sudah pernah belajar tentang angka bulat kan di sekolah?

Cara menggunakan int() seperti ini:

bulat = int(1.23)
Mirip seperti kita menggunakan str(), tetapi kali ini kita akan mendapatkan sebuah angka bulat dari int ini alih-alih mendapatkan string.'''

'''Di samping kita punya variabel bernama pi yang memiliki nilai tidak bulat (float). Simpan nilai integer dari pi di variabel pi_bulat.'''