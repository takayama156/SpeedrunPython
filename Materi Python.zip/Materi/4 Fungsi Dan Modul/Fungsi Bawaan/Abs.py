angka_minus = -3.14

angka_positif = abs(angka_minus)

print(angka_minus)
print(angka_positif)

'''Fungsi abs() berguna untuk memberikan nilai absolut dari sebuah angka. Cara menggunakannya seperti ini:

print abs(-1)
print abs(1)
Kedua baris tersebut akan menghasilkan 1. Fungsi abs() juga menerima variabel seperti ini:

angka = -1
print abs(angka)'''

'''Instruksi:
Definisikan angka_positif memiliki nilai absolut dari angka_minus dengan menggunakan fungsi abs().'''