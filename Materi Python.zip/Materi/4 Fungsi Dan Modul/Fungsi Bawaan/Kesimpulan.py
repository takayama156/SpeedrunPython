# Yeah anda sudah lebih dari setengah di pelajaran Python!
def diskon(harga):
  if harga > 300:
    return harga/float(10)
  elif harga > 100:
    return harga/float(20)
  else:
    return 0

print(diskon(333))

print(diskon(111))

'''Sekarang mari kita ulas apa yang anda telah pelajari di sini:

int(2.718) # 2
float(3) / 4 # 0.75
max(1 , 3, 5) # 5
min(1, 3, 5) # 1

range(4) # 0, 1, 2, 3
range(1,4) # 1, 2, 3
range(0,4,2) # 0, 2'''

'''Tugas kita kali ini simpel saja. Mari kita perbaiki fungsi diskon() yang telah kita buat sebelumnya. Kelemahan fungsi diskon() kita ini adalah akan mengembalikan nilai bulat dengan mengabaikan nilai di belakang koma. Mari perbaiki dengan memberikan float() di setiap return harga. '''

'''Tentunya ini bukan semua function built-in yang ada di Python. Untuk daftar lengkapnya bisa lihat di dokumen resmi dari Python.'''