print(223 / float(6))

'''Selain bilangan bulat, kita punya juga bilangan tidak bulat atau bilangan yang memiliki nilai koma. Apa ya istilahnya yang tepat di bahasa Indonesia? Menurut wiki itu adalah bilangan titik mengambang. Anyway, di dunia programming disebut sebagi float. Cara menggunakannya anda pasti sudah bisa menebaknya:

ngambang = float(2)
yang akan membuat ngambang bernilai 2.0.

Di Python float dan int itu penting dan terkadang bisa menjadi sumber bencana! Misalnya:

tabungan = 31 / 3

if tabungan > 10:
  print "Beli laptop baru!"
else:
  print "Nabung lagi"
tabungan anda sebenernya lebih dari 10, tetapi karena 31 / 3 itu adalah integer, maka tabungan akan memiliki nilai tepat 10. Yang artinya anda tidak akan membeli laptop baru. Bencana besar bukan?

Cara memperbaikinya mudah yaitu hanya dengan memberikan float() di salah satu angkanya, seperti ini: float(31) / 3'''

'''Sederhana saja, berikan float() untuk code di samping sehingga mengeluarkan bilangan float.'''