besar = max(12,200,32,900)

kecil = min(20,-30,100,93)

print(besar)
print(kecil)

'''Fungsi max() adalah fungsi yang menerima parameter dalam jumlah yang bebas dan akan mengembalikan suatu angka yang terbesar dari yang diberikan. Contohnya max(1,2,3,4) akan memberikan nilai 4.

Fungsi min() sama persis seperti max(), hanya saja akan mengembalikan nilai yang terkecil. Contohnya min(1,2,3,4) akan mengembalikan nilai 1.'''

'''Di variabel besar, gunankan max() untuk mencari mana yang terbesar dari angka 12, 900, dan 32.
Di variabel kecil, gunakan min() untuk mencari nilai terkecil dari angka 20, -30, 100, dan 93.'''