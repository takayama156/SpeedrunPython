Sebelum mulai mempelajari semua materi di zip ini, pastikan agan sudah menginstall IDE yang dapat menjalankan Python atau untuk user android bisa menggunakan App Quickedit Di awal-awal lalu mulai menggunakan Pydroid Di kelanjutannya

Anda juga dapat menggunakan Termux untuk menjalankan file python, caranya:
       1.install python menggunakan command
         pkg install python3
       2.gunakan perintah cd, contohnya /storage/emulated/0/ (Anda dapat menggunakan zarchiver untuk mengentahui letak foldernya)
       3.pastikan file py yang ingin anda jalankan ada di folder itu
       4.untuk membukanya ketik perintah berikut: python nama_file.py
       
Semua File yang ada Dimateri diambil dari Website Codesaya

Beberapa script difolder contoh mengharuskan anda mengginstall modul tambahan

Pastikan modul berikut telah terinstall (Gunakan Termux)
1.Tabulate: pip install tabulate